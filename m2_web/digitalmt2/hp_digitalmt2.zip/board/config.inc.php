<?php
// com.woltlab.wbb vars
// wbb
if (!defined('WBB_DIR')) define('WBB_DIR', dirname(__FILE__).'/');
if (!defined('RELATIVE_WBB_DIR')) define('RELATIVE_WBB_DIR', '');
if (!defined('WBB_N')) define('WBB_N', '1_1');
$packageDirs[] = WBB_DIR;

// general info
if (!defined('RELATIVE_WCF_DIR'))	define('RELATIVE_WCF_DIR', RELATIVE_WBB_DIR.'wcf/');
if (!defined('PACKAGE_ID')) define('PACKAGE_ID', 27);
if (!defined('PACKAGE_NAME')) define('PACKAGE_NAME', 'WoltLab Burning Board Lite');
if (!defined('PACKAGE_VERSION')) define('PACKAGE_VERSION', '2.1.2 pl 1');
?>