<?php
$dbHost = 'LURRDOCK.RO';
$dbUser = 'LURRDOCK.RO';
$dbPassword = 'LURRDOCK.RO';
$dbName = 'LURRDOCK.RO';
$dbCharset = 'utf8';
$dbClass = 'MySQLDatabase';
if (!defined('WCF_N')) define('WCF_N', 1);
?>