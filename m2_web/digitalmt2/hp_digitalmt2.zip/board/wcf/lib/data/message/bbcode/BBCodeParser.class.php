<?php
/**
 * Parses bbcode tags in text.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2009 WoltLab GmbH
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 * @package	com.woltlab.wcf.data.message.bbcode
 * @subpackage	data.message.bbcode
 * @category 	Community Framework
 */
class BBCodeParser {
	protected $outputType = '';
	protected $definedTags = array();
	protected $text = '';
	protected $parsedText = '';
	protected $tagArray = array();
	protected $textArray = array();
	protected $bbcodeObjects = array();
	
	/**
	 * Creates a new BBCodeParser object.
	 * 
	 * @param	string		$outputType
	 */
	public function __construct($outputType = 'text/html') {
		$this->setOutputType($outputType);
		
		// get bbcodes
		$this->definedTags = WCF::getCache()->get('bbcodes', 'all');
	}
	
	/**
	 * Sets the output type of the parser.
	 */
	public function setOutputType($outputType) {
		$this->outputType = $outputType;
	}
	
	/**
	 * Returns the current output type.
	 * @return	string
	 */
	public function getOutputType() {
		return $this->outputType;
	}
	
	/**
	 * Sets the text to be parsed.
	 * 
	 * @param	string		$text
	 */
	public function setText($text) {
		$this->text = $text;
	}
	
	/**
	 * Parses the given text.
	 * 
	 * @param	string		$text
	 */
	public function parse($text) {
		$this->setText($text);
		$this->buildTagArray();
		$this->buildXMLStructure();
		$this->buildParsedString();
		
		return $this->parsedText;
	}
	
	/**
	 * Builds a valid xml structure of bbcode tags.
	 * Inserts unclosed tags automatically.
	 */
	public function buildXMLStructure() {
		// stack for open tags
		$openTagStack = $openTagDataStack = array();
		$newTagArray = array();
		$newTextArray = array();		
		
		$i = -1;
		foreach ($this->tagArray as $i => $tag) {
			if ($tag['closing']) {
				// closing tag
				if (in_array($tag['name'], $openTagStack) && $this->isAllowed($openTagStack, $tag['name'], true)) {
					// close unclosed tags
					$tmpOpenTags = array();
					while (($previousTag = end($openTagStack)) != $tag['name']) {
						$nextIndex = count($newTagArray);
						$newTagArray[$nextIndex] = $this->buildTag('[/'.$previousTag.']');
						if (!isset($newTextArray[$nextIndex])) $newTextArray[$nextIndex] = '';
						$newTextArray[$nextIndex] .= $this->textArray[$i];
						$this->textArray[$i] = '';
						$tmpOpenTags[] = end($openTagDataStack);
						array_pop($openTagStack);
						array_pop($openTagDataStack);
					}
					
					$nextIndex = count($newTagArray);
					$newTagArray[$nextIndex] = $tag;
					array_pop($openTagStack);
					array_pop($openTagDataStack);
					if (!isset($newTextArray[$nextIndex])) $newTextArray[$nextIndex] = '';
					$newTextArray[$nextIndex] .= $this->textArray[$i];
					
					// open closed unclosed tags
					while ($tmpTag = end($tmpOpenTags)) {
						$nextIndex = count($newTagArray);
						$newTagArray[$nextIndex] = $tmpTag;
						if (!isset($newTextArray[$nextIndex])) $newTextArray[$nextIndex] = '';
						$openTagStack[] = $tmpTag['name'];
						$openTagDataStack[] = $tmpTag;
						array_pop($tmpOpenTags);
					}
				}
				else {
					// no such tag open
					// handle as plain text
					$this->textArray[$i] .= $tag['source'];
					$last = count($newTagArray);
					if (!isset($newTextArray[$last])) $newTextArray[$last] = '';
					$newTextArray[$last] .= $this->textArray[$i];
				}
			}
			else {
				// opening tag
				if ($this->isAllowed($openTagStack, $tag['name']) && $this->isValidTag($tag)) {
					$openTagStack[] = $tag['name'];
					$openTagDataStack[] = $tag;
					$nextIndex = count($newTagArray);
					$newTagArray[$nextIndex] = $tag;
					if (!isset($newTextArray[$nextIndex])) $newTextArray[$nextIndex] = '';
					$newTextArray[$nextIndex] .= $this->textArray[$i];
				}
				else {
					// tag not allowed
					$this->textArray[$i] .= $tag['source'];
					$last = count($newTagArray);
					if (!isset($newTextArray[$last])) $newTextArray[$last] = '';
					$newTextArray[$last] .= $this->textArray[$i];
				}
			}
		}
		
		$last = count($newTagArray);
		if (!isset($newTextArray[$last])) $newTextArray[$last] = '';
		$newTextArray[$last] .= $this->textArray[$i + 1];
		
		// close unclosed open tags
		while (end($openTagStack)) {
			$nextIndex = count($newTagArray);
			$newTagArray[$nextIndex] = $this->buildTag('[/'.end($openTagStack).']');
			if (!isset($newTextArray[$nextIndex])) $newTextArray[$nextIndex] = '';
			array_pop($openTagStack);
			array_pop($openTagDataStack);
		}
		
		$this->tagArray = $newTagArray;
		$this->textArray = $newTextArray;
	}
	
	/**
	 * Validates the attributes of a tag.
	 * 
	 * @param	array		$tag
	 * @return	boolean
	 */
	protected function isValidTag($tag) {
		if (isset($tag['attributes']) && count($tag['attributes']) > count($this->definedTags[$tag['name']]['attributes'])) {
			return false;
		}
		
		foreach ($this->definedTags[$tag['name']]['attributes'] as $attribute) {
			if (!$this->isValidTagAttribute((isset($tag['attributes']) ? $tag['attributes'] : array()), $attribute)) {
				return false;
			}
		}
		
		return true;
	}
	
	/**
	 * Validates an attributes of a tag.
	 * 
	 * @param	array		$tagAttributes
	 * @param 	array		$definedTagAttribute
	 * @return	boolean
	 */
	protected function isValidTagAttribute($tagAttributes, $definedTagAttribute) {
		if ($definedTagAttribute['validationPattern'] && isset($tagAttributes[$definedTagAttribute['attributeNo']])) {
			// validate attribute
			if (!preg_match('~'.$definedTagAttribute['validationPattern'].'~i', $tagAttributes[$definedTagAttribute['attributeNo']])) {
				return false;
			}
		}
			
		if ($definedTagAttribute['required'] && !$definedTagAttribute['useText'] && !isset($tagAttributes[$definedTagAttribute['attributeNo']])) {
			return false;
		}
		
		return true;
	}
	
	/**
	 * Returns true, if the text inside the given text needs to be buffered.
	 * 
	 * @param	string		$tag
	 * @return	boolean
	 */
	protected function needBuffering($tag) {
		// check for special bbcode class
		if (!empty($this->definedTags[$tag['name']]['className'])) {
			return true;
		}

		// search 'useText' attributes
		foreach ($this->definedTags[$tag['name']]['attributes'] as $attribute) {
			if ($attribute['useText'] && !isset($tag['attributes'][$attribute['attributeNo']])) {
				return true;
			}
		}
	
		return false;
	}
	
	/**
	 * Builds the opening tag.
	 * 
	 * @param	array		$tag
	 * @return	string
	 */
	protected function buildOpeningTag($tag) {
		// build attributes
		$attributesString = '';
		foreach ($this->definedTags[$tag['name']]['attributes'] as $attribute) {
			if (isset($tag['attributes'][$attribute['attributeNo']])) {
				$atrributeString = '';
				if ($this->outputType == 'text/html' && !empty($attribute['attributeHtml'])) {
					$atrributeString = ' '.$attribute['attributeHtml'];
				}
				if ($this->outputType == 'text/plain') {
					$atrributeString = $attribute['attributeText'];
				}
				
				if (!empty($atrributeString)) {
					$attributesString .= sprintf($atrributeString, $tag['attributes'][$attribute['attributeNo']]);
				}
			}
		}
		
		// build tag
		if ($this->outputType == 'text/html') {
			if (!empty($this->definedTags[$tag['name']]['htmlOpen'])) {
				return '<'.$this->definedTags[$tag['name']]['htmlOpen'].$attributesString.(empty($this->definedTags[$tag['name']]['htmlClose']) ? ' /' : '').'>';
			}
		}
		else if ($this->outputType == 'text/plain') {
			if (!empty($this->definedTags[$tag['name']]['textOpen']) || !empty($attributesString)) {
				return $this->definedTags[$tag['name']]['textOpen'].$attributesString;
			}
		}
		
		return '';
	}
	
	/**
	 * Builds the closing tag.
	 * 
	 * @param	array		$tag
	 * @return	string
	 */
	protected function buildClosingTag($tag) {
		if ($this->outputType == 'text/html') {
			if (!empty($this->definedTags[$tag['name']]['htmlClose'])) {
				return '</'.$this->definedTags[$tag['name']]['htmlClose'].'>';
			}
		}
		else if ($this->outputType == 'text/plain') {
			return $this->definedTags[$tag['name']]['textClose'];
		}
		
		return '';
	}
	
	/**
	 * Returns true, if $tag is allowed in open tags.
	 * 
	 * @param	array		$openTags		list of open tags
	 * @param	array		$tag
	 * @return	boolean
	 */
	protected function isAllowed($openTags, $tag, $closing = false) {
		foreach ($openTags as $openTag) {
			if ($closing && $openTag == $tag) continue;
			if ($this->definedTags[$openTag]['allowedChildren'] == 'all') continue;
			if ($this->definedTags[$openTag]['allowedChildren'] == 'none') return false;

			$arguments = explode('^', $this->definedTags[$openTag]['allowedChildren']);
			if (!empty($arguments[1])) $tags = explode(',', $arguments[1]);
			else $tags = array();
			
			if ($arguments[0] == 'none' && !in_array($tag, $tags)) return false;
			if ($arguments[0] == 'all' && in_array($tag, $tags)) return false;
		}
		
		return true;
	}
	
	/**
	 * Builds the parsed string.
	 */
	public function buildParsedString() {
		// reset parsed text
		$this->parsedText = '';
		
		// create text buffer
		$buffer =& $this->parsedText;
		
		// stack of buffered tags
		$bufferedTagStack = array();

		// loop through the tags
		$i = -1;
		foreach ($this->tagArray as $i => $tag) {
			// append text to buffer
			$buffer .= $this->textArray[$i];
			
			if ($tag['closing']) {
				// get buffered opening tag
				$openingTag = end($bufferedTagStack);
				
				// closing tag
				if ($openingTag && $openingTag['name'] == $tag['name']) {
					$hideBuffer = false;
					// insert buffered content as attribute value
					foreach ($this->definedTags[$tag['name']]['attributes'] as $attribute) {
						if ($attribute['useText'] && !isset($openingTag['attributes'][$attribute['attributeNo']])) {
							$openingTag['attributes'][$attribute['attributeNo']] = $buffer;
							$hideBuffer = true;
							break;
						}
					}
					
					// validate tag attributes again
					if ($this->isValidTag($openingTag)) {
						if ($this->definedTags[$tag['name']]['className']) {
							// get bbcode object
							$bbcodeObj = $this->getBBCodeObject($tag['name']);
							
							// build tag
							$parsedTag = $bbcodeObj->getParsedTag($openingTag, $buffer, $tag, $this);
						}
						else {
							// build tag
							$parsedTag = $this->buildOpeningTag($openingTag);
							$closingTag = $this->buildClosingTag($tag);
							if (!empty($closingTag) && $hideBuffer) $parsedTag .= $buffer.$closingTag;
						}
					}
					else {
						$parsedTag = $openingTag['source'].$buffer.$tag['source'];
					}
					
					// close current buffer
					array_pop($bufferedTagStack);
					
					// open previous buffer
					if (count($bufferedTagStack) > 0) {
						$bufferedTag =& $bufferedTagStack[count($bufferedTagStack) - 1];
						$buffer =& $bufferedTag['buffer'];
					}
					else {
						$buffer =& $this->parsedText;
					}
					
					// append parsed tag
					$buffer .= $parsedTag;
				}
				else {
					$buffer .= $this->buildClosingTag($tag);
				}
			}
			else {
				// opening tag
				if ($this->needBuffering($tag)) {
					// start buffering
					$tag['buffer'] = '';
					$bufferedTagStack[] = $tag;
					$buffer =& $bufferedTagStack[(count($bufferedTagStack) - 1)]['buffer'];
				}
				else {
					$buffer .= $this->buildOpeningTag($tag);
				}
			}
		}
		
		if (isset($this->textArray[$i + 1])) $this->parsedText .= $this->textArray[$i + 1];
	}
	
	/**
	 * Builds the tag array from the given text.
	 */
	public function buildTagArray() {
		// build tag pattern
		$validTags = '';
		foreach ($this->definedTags as $tag => $data) {
			if (!$data['sourceCode']) { // remove source codes
				if (!empty($validTags)) $validTags .= '|';
				$validTags .= $tag;
			}
		}
		$pattern = '~\[(?:/(?:'.$validTags.')|(?:'.$validTags.')
			(?:=
				(?:\'[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*\'|[^,\]]*)
				(?:,(?:\'[^\'\\\\]*(?:\\\\.[^\'\\\\]*)*\'|[^,\]]*))*
			)?)\]~ix';
		
		// get bbcode tags
		preg_match_all($pattern, $this->text, $matches);
		$this->tagArray = $matches[0];
		unset($matches);
		
		// build tags
		for ($i = 0, $j = count($this->tagArray); $i < $j; $i++) {
			$this->tagArray[$i] = $this->buildTag($this->tagArray[$i]);
		}
		
		// get text
		$this->textArray = preg_split($pattern, $this->text);
	}
	
	/**
	 * Builds a bbcode tag.
	 * 
	 * @param	string		$string
	 * @return	array		bbcode tag data
	 */
	protected function buildTag($string) {
		$tag = array('name' => '', 'closing' => false, 'source' => $string);
	
		if (StringUtil::substring($string, 1, 1) == '/') {
			// closing tag
			$tag['name'] = StringUtil::toLowerCase(StringUtil::substring($string, 2, StringUtil::length($string) - 3));
			$tag['closing'] = true;
		}
		else {
			// opening tag
			// split tag and attributes
			preg_match("!^\[([a-z0-9]+)=?(.*)]$!si", $string, $match);
			$tag['name'] = StringUtil::toLowerCase($match[1]);
			
			// build attributes
			if (!empty($match[2])) {
				$tag['attributes'] = $this->buildTagAttributes($match[2]);
			}
		}
		
		return $tag;
	}
	
	/**
	 * Builds the attributes of a bbcode tag.
	 * 
	 * @param	string		$string
	 * @return	array		bbcode attributes
	 */
	protected function buildTagAttributes($string) {
		preg_match_all("~(?:^|,)('[^'\\\\]*(?:\\\\.[^'\\\\]*)*'|[^,]*)~", $string, $matches);
		
		// remove quotes
		for ($i = 0, $j = count($matches[1]); $i < $j; $i++) {
			if (StringUtil::substring($matches[1][$i], 0, 1) == "'" && StringUtil::substring($matches[1][$i], -1) == "'") {
				$matches[1][$i] = StringUtil::replace("\'", "'", $matches[1][$i]);
				$matches[1][$i] = StringUtil::replace("\\\\", "\\", $matches[1][$i]);
				
				$matches[1][$i] = StringUtil::substring($matches[1][$i], 1, -1);
			}
		}
		
		return $matches[1];
	}
	
	/**
	 * Returns the object of a special bbcode.
	 * 
	 * @param	string		$tagName
	 * @return	BBCode
	 */
	protected function getBBCodeObject($tagName) {
		if (!isset($this->bbcodeObjects[$tagName])) {
			$className = $this->definedTags[$tagName]['className'];
			$classPath = WCF_DIR.'lib/data/message/bbcode/'.$className.'.class.php';
			
			// include class file
			if (!file_exists($classPath)) {
				throw new SystemException("unable to find class file '".$classPath."'", 11000);
			}
			require_once($classPath);
			
			// build object
			if (!class_exists($className)) {
				throw new SystemException("unable to find class '".$className."'", 11001);
			}
			
			$this->bbcodeObjects[$tagName] = new $className();
		}
		
		return $this->bbcodeObjects[$tagName];
	}
}
?>