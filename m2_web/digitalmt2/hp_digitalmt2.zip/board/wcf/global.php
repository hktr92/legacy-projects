<?php
/**
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	GNU Lesser General Public License <http://opensource.org/licenses/lgpl-license.php>
 */
define('WCF_DIR', dirname(__FILE__).'/');

// initiate WCF Framework
require_once(WCF_DIR.'lib/system/WCF.class.php');
?>