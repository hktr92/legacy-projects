<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');
require_once(WBB_DIR.'lib/data/post/ViewablePost.class.php');
require_once(WBB_DIR.'lib/data/thread/ViewableThread.class.php');
require_once(WBB_DIR.'lib/data/post/ThreadPostList.class.php');

// wcf imports
require_once(WCF_DIR.'lib/page/MultipleLinkPage.class.php');
require_once(WCF_DIR.'lib/data/message/sidebar/MessageSidebarFactory.class.php');

/**
 * This class provides the ability to render a thread page.
 *
 * @author 	Marcel Werk
 * @copyright	2001-2010 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	page
 * @category 	Burning Board
 */
class ThreadPage extends MultipleLinkPage {
	// system
	public $templateName = 'thread';
	public $itemsPerPage = THREAD_POSTS_PER_PAGE;
	
	// parameters
	public $threadID = 0, $postID = 0;
	public $highlight = '';
	
	/**
	 * board of this thread.
	 * 
	 * @var	Board
	 */
	public $board = null;
	
	/**
	 * this thread
	 * 
	 * @var	ViewableThread
	 */
	public $thread = null;
	
	/**
	 * list of posts.
	 * 
	 * @var	ThreadPostList 
	 */
	public $postList = null;
	
	/**
	 * sidebar factory object
	 * 
	 * @var	MessageSidebarFactory
	 */
	public $sidebarFactory = null;
	
	/**
	 * Reads the given parameters.
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['threadID'])) $this->threadID = intval($_REQUEST['threadID']);
		else if (isset($_REQUEST['threadid'])) $this->threadID = intval($_REQUEST['threadid']); // wbb2 style
		if (isset($_REQUEST['messageID'])) $this->postID = intval($_REQUEST['messageID']);
		else if (isset($_REQUEST['postID'])) $this->postID = intval($_REQUEST['postID']);
		else if (isset($_REQUEST['postid'])) $this->postID = intval($_REQUEST['postid']); // wbb2 style
		if (isset($_REQUEST['action'])) $this->action = $_REQUEST['action'];
		if (isset($_REQUEST['highlight'])) $this->highlight = $_REQUEST['highlight'];
		
		// get thread
		$this->thread = new ViewableThread($this->threadID, null, $this->postID);
		$this->threadID = $this->thread->threadID;
		
		// get board
		$this->board = Board::getBoard($this->thread->boardID);
		
		// posts per page
		if ($this->board->postsPerPage) $this->itemsPerPage = $this->board->postsPerPage;
		if (WCF::getUser()->postsPerPage) $this->itemsPerPage = WCF::getUser()->postsPerPage;
		
		// enter thread
		$this->thread->enter($this->board);
		
		// init post list
		$this->postList = new ThreadPostList($this->thread, $this->board);
		
		// mark thread as read
		if ($this->action == 'markAsRead') {
			if ($this->thread->isNew()) WCF::getUser()->setThreadVisitTime($this->threadID, TIME_NOW);
			exit;
		}
		
		// handle jump to
		if ($this->action == 'lastPost') $this->goToLastPost();
		if ($this->action == 'firstNew') $this->goToFirstNewPost();
		if ($this->postID) $this->goToPost();
		
		// handle parameters and special actions
		if (!WCF::getSession()->spiderID) {
			$this->updateViews();
		}
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		// get posts
		$this->postList->offset = ($this->pageNo - 1) * $this->itemsPerPage;
		$this->postList->limit = $this->itemsPerPage;
		$this->postList->readPosts();
		
		// update thread visit
		if ($this->thread->isNew() && $this->postList->maxPostTime > $this->thread->lastVisitTime) {
			WCF::getUser()->setThreadVisitTime($this->threadID, $this->postList->maxPostTime);
		}
		
		// init sidebars
		$this->sidebarFactory = new MessageSidebarFactory($this);
		foreach ($this->postList->posts as $post) {
			$this->sidebarFactory->create($post);
		}
		$this->sidebarFactory->init();
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'board' => $this->board,
			'thread' => $this->thread,
			'threadID' => $this->threadID,
			'postID' => $this->postID,
			'boardQuickJumpOptions' => Board::getBoardSelect(),
			'showAvatar' => (!WCF::getUser()->userID || WCF::getUser()->showAvatar),
			'highlight' => $this->highlight,
			'posts' => $this->postList->posts,
			'userData' => $this->postList->userData,
			'allowSpidersToIndexThisPage' => true,
			'polls' => $this->postList->polls,
			'attachments' => $this->postList->attachments,
			'sidebarFactory' => $this->sidebarFactory
		));
		
		if (WCF::getSession()->spiderID) {
			@header('Last-Modified: '.gmdate('D, d M Y H:i:s', $this->thread->lastPostTime).' GMT');
		}
	}
	
	/**
	 * @see MultipleLinkPage::countItems()
	 */
	public function countItems() {
		parent::countItems();
		
		return $this->postList->countPosts();
	}

	/**
	 * Calculates the position of a specific post in this thread.
	 */
	protected function goToPost() {
		$sql = "SELECT	COUNT(*) AS posts
			FROM 	wbb".WBB_N."_post
			WHERE 	threadID = ".$this->threadID."
				".$this->postList->sqlConditionVisible."
				AND time <= ".$this->thread->getPost()->time;
		$result = WCF::getDB()->getFirstRow($sql);
		$this->pageNo = intval(ceil($result['posts'] / $this->itemsPerPage));
	}
	
	/**
	 * Gets the post id of the last post in this thread and forwards the user to this post.
	 */
	protected function goToLastPost() {
		$sql = "SELECT		postID
			FROM 		wbb".WBB_N."_post
			WHERE 		threadID = ".$this->threadID.
					$this->postList->sqlConditionVisible."
			ORDER BY 	time DESC";
		$result = WCF::getDB()->getFirstRow($sql);
		HeaderUtil::redirect('index.php?page=Thread&postID=' . $result['postID'] . SID_ARG_2ND_NOT_ENCODED . '#post' . $result['postID'], true, true);
		exit;
	}
	
	/**
	 * Forwards the user to the first new post in this thread.
	 */
	protected function goToFirstNewPost() {
		$lastVisitTime = intval($this->thread->lastVisitTime);
		$sql = "SELECT		postID
			FROM 		wbb".WBB_N."_post
			WHERE 		threadID = ".$this->threadID.
					$this->postList->sqlConditionVisible."
					AND time > ".$lastVisitTime."
			ORDER BY 	time ASC";
		$result = WCF::getDB()->getFirstRow($sql);
		if (isset($result['postID'])) {
			HeaderUtil::redirect('index.php?page=Thread&postID=' . $result['postID'] . SID_ARG_2ND_NOT_ENCODED . '#post' . $result['postID'], true, true);
			exit;
		}
		else $this->goToLastPost();
	}
	
	/**
	 * Updates the views of this thread.
	 */
	public function updateViews() {
		$sql = "UPDATE	wbb".WBB_N."_thread
			SET 	views = views + 1
			WHERE 	threadID = " . $this->threadID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
}
?>