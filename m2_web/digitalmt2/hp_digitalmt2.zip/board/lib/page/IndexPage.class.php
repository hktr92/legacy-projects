<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/BoardList.class.php');

// wcf imports
require_once(WCF_DIR.'lib/page/AbstractPage.class.php');

/**
 * Shows the start page of the forum.
 *
 * @package	com.woltlab.wbb.page
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class IndexPage extends AbstractPage {
	public $templateName = 'index';
	
	/**
	 * @see Page::assignVariables();
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		$this->renderBoards();
		if (INDEX_ENABLE_STATS) {
			$this->renderStats();
		}
		WCF::getTPL()->assign(array(
			'selfLink' => 'index.php?page=Index'.SID_ARG_2ND_NOT_ENCODED,
			'allowSpidersToIndexThisPage' => true
		));
		
		if (WCF::getSession()->spiderID) {
			if ($lastChangeTime = @filemtime(WBB_DIR.'cache/cache.stat.php')) {
				@header('Last-Modified: '.gmdate('D, d M Y H:i:s', $lastChangeTime).' GMT');
			}
		}
	}
	
	/**
	 * Renders the forum stats on the index page.
	 */
	protected function renderStats() {
		$stats = WCF::getCache()->get('stat');
		WCF::getTPL()->assign('stats', $stats);
	}
	
	/**
	 * @see BoardList::renderBoards()
	 */
	protected function renderBoards() {
		$boardList = new BoardList();
		$boardList->renderBoards();
	}
}
?>