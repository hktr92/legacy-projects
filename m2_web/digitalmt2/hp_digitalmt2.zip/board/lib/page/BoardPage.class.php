<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');

// wcf imports
require_once(WCF_DIR.'lib/page/SortablePage.class.php');

/**
 * Shows the board page.
 *
 * @author 	Marcel Werk
 * @copyright	2001-2010 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	page
 * @category 	Burning Board
 */
class BoardPage extends SortablePage {
	// default values
	public $defaultSortField = BOARD_DEFAULT_SORT_FIELD;
	public $defaultSortOrder = BOARD_DEFAULT_SORT_ORDER;
	public $itemsPerPage = BOARD_THREADS_PER_PAGE;
	
	// board data
	public $boardID = 0;
	public $board;
	
	// system
	public $templateName = 'board';
	public $boardList = null;
	public $threadList = null;
	
	/**
	 * Reads the given parameters.
	 */
	public function readParameters() {
		parent::readParameters();
		
		// get board id
		if (isset($_REQUEST['boardID'])) $this->boardID = intval($_REQUEST['boardID']);
		else if (isset($_REQUEST['boardid'])) $this->boardID = intval($_REQUEST['boardid']); // wbb2 style
		
		// get board
		$this->board = new Board($this->boardID);
		
		// threads per page
		if ($this->board->threadsPerPage) $this->itemsPerPage = $this->board->threadsPerPage;
		if (WCF::getUser()->threadsPerPage) $this->itemsPerPage = WCF::getUser()->threadsPerPage;
		
		// enter board
		$this->board->enter();
		
		// get sorting values
		if ($this->board->sortField) $this->defaultSortField = $this->board->sortField;
		if ($this->board->sortOrder) $this->defaultSortOrder = $this->board->sortOrder;
		
		$this->handleAction();
		
		if ($this->board->isBoard()) {
			require_once(WBB_DIR.'lib/data/thread/BoardThreadList.class.php');
			$this->threadList = new BoardThreadList($this->board);
		}
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		// generate list of subboards
		$this->renderBoards();
		
		// get threads
		if ($this->threadList != null) {
			$this->threadList->limit = $this->itemsPerPage;
			$this->threadList->offset = ($this->pageNo - 1) * $this->itemsPerPage;
			$this->threadList->sqlOrderBy = $this->sortField." ".$this->sortOrder . 
							(($this->sortField != 'lastPostTime') ? (", lastPostTime DESC") : (''));
			$this->threadList->readThreads();
		}
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'board' => $this->board,
			'boardID' => $this->boardID,
			'boardQuickJumpOptions' => Board::getBoardSelect(),
			'normalThreads' => ($this->threadList != null ? $this->threadList->threads : null),
			'allowSpidersToIndexThisPage' => true,
			'defaultSortField' => $this->defaultSortField,
			'defaultSortOrder' => $this->defaultSortOrder
		));
		
		if (WCF::getSession()->spiderID) {
			if ($this->threadList != null && $this->threadList->maxLastPostTime) {
				@header('Last-Modified: '.gmdate('D, d M Y H:i:s', $this->threadList->maxLastPostTime).' GMT');
			}
		}
	}
	
	/**
	 * Handles the action request.
	 */
	protected function handleAction() {
		switch ($this->action) {
			case 'markAsRead': 
				$this->board->markAsRead();
				if (isset($_REQUEST['ajax'])) exit;
				HeaderUtil::redirect('index.php?page=Board&boardID='.$this->boardID.SID_ARG_2ND_NOT_ENCODED);
				exit;
		}
	}
	
	/**
	 * Wrapper for BoardList->renderBoards()
	 * @see BoardList::renderBoards()
	 */
	protected function renderBoards() {
		if ($this->boardList === null) {
			require_once(WBB_DIR.'lib/data/board/BoardList.class.php');
			$this->boardList = new BoardList($this->boardID);
		}
		$this->boardList->renderBoards();
	}
	
	/**
	 * @see MultipleLinkPage::countItems()
	 */
	public function countItems() {
		parent::countItems();
		
		if ($this->threadList == null) return 0;
		return $this->threadList->countThreads();
	}
	
	/**
	 * @see SortablePage::validateSortField()
	 */
	public function validateSortField() {
		parent::validateSortField();
		
		switch ($this->sortField) {
			case 'topic':
			case 'username':
			case 'time':
			case 'views':
			case 'replies':
			case 'lastPostTime': break;
			default: $this->sortField = $this->defaultSortField;
		}
	}
}
?>