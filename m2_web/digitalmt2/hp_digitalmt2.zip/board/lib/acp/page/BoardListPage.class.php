<?php
// wcf imports
require_once(WCF_DIR.'lib/page/AbstractPage.class.php');

// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');

/**
 * Shows a list of all boards.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.acp.page
 */
class BoardListPage extends AbstractPage {
	public $templateName = 'boardList';
	public $boardStructure, $boards;
	public $boardList = array();
	public $deletedBoardID = 0;
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['deletedBoardID'])) $this->deletedBoardID = intval($_REQUEST['deletedBoardID']);
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		$this->renderBoards();
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'boards' => $this->boardList,
			'deletedBoardID' => $this->deletedBoardID
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		// enable menu item
		WCFACP::getMenu()->setActiveMenuItem('wbb.acp.menu.link.content.board.view');
		
		// check permission
		WCF::getUser()->checkPermission(array('admin.board.canEditBoard', 'admin.board.canDeleteBoard', 'admin.board.canEditPermissions', 'admin.board.canEditModerators'));
		
		parent::show();
	}
	
	/**
	 * Renders the ordered list of all boards.
	 */
	protected function renderBoards() {
		// get board structure from cache		
		$this->boardStructure = WCF::getCache()->get('board', 'boardStructure');
		// get boards from cache
		$this->boards = WCF::getCache()->get('board', 'boards');
				
		$this->makeBoardList();
	}
	
	/**
	 * Renders one level of the board structure.
	 *
	 * @param	integer		parentID		render the subboards of the board with the given id
	 * @param	integer		depth			the depth of the current level
	 * @param	integer		openParents		helping variable for rendering the html list in the boardlist template
	 */
	protected function makeBoardList($parentID = 0, $depth = 1, $openParents = 0) {
		if (!isset($this->boardStructure[$parentID])) return;
		
		$i = 0; $children = count($this->boardStructure[$parentID]);
		foreach ($this->boardStructure[$parentID] as $boardID) {
			$board = $this->boards[$boardID];
			
			// boardlist depth on index
			$childrenOpenParents = $openParents + 1;
			$hasChildren = isset($this->boardStructure[$boardID]);
			$last = $i == count($this->boardStructure[$parentID]) - 1;
			if ($hasChildren && !$last) $childrenOpenParents = 1;
			$this->boardList[] = array('depth' => $depth, 'hasChildren' => $hasChildren, 'openParents' => ((!$hasChildren && $last) ? ($openParents) : (0)), 'board' => $board, 'parentID' => $parentID, 'position' => $i+1, 'maxPosition' => $children);
			
			// make next level of the board list
			$this->makeBoardList($boardID, $depth + 1, $childrenOpenParents);
			
			$i++;
		}
	}
}
?>