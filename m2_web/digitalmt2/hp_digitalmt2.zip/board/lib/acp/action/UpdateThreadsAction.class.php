<?php
require_once(WBB_DIR.'lib/acp/action/UpdateCounterAction.class.php');

/**
 * Updates the threads.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.acp.action
 */
class UpdateThreadsAction extends UpdateCounterAction {
	public $action = 'UpdateThreads';
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// count thread
		$sql = "SELECT	COUNT(*) AS count
			FROM	wbb".WBB_N."_thread
			WHERE	movedThreadID = 0";
		$row = WCF::getDB()->getFirstRow($sql);
		$count = $row['count'];
		
		// get thread ids
		$threadIDs = '';
		$sql = "SELECT		threadID
			FROM		wbb".WBB_N."_thread
			WHERE		movedThreadID = 0
			ORDER BY	threadID";
		$result = WCF::getDB()->sendQuery($sql, $this->limit, ($this->limit * $this->loop));
		while ($row = WCF::getDB()->fetchArray($result)) {
			$threadIDs .= ','.$row['threadID'];
		}
		
		if (empty($threadIDs)) {
			$this->calcProgress();
			$this->finish();
		}
		
		// update threads
		$sql = "UPDATE	wbb".WBB_N."_thread thread
			SET	lastPostTime = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		time
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
								AND isDeleted = 0
								AND isDisabled = 0
						ORDER BY	time DESC
					", 1)."
				), time),
				lastPosterID = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		userID
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
								AND isDeleted = 0
								AND isDisabled = 0
						ORDER BY	time DESC
					", 1)."
				), 0),
				lastPoster = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		username
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
								AND isDeleted = 0
								AND isDisabled = 0
						ORDER BY	time DESC
					", 1)."
				), ''),
				replies = GREATEST((
					SELECT 	COUNT(*) - 1
					FROM 	wbb".WBB_N."_post
					WHERE 	threadID = thread.threadID
						AND isDeleted = 0
						AND isDisabled = 0
				), 0),
				attachments = IFNULL((
					SELECT	SUM(attachments)
					FROM	wbb".WBB_N."_post
					WHERE 	threadID = thread.threadID
						AND isDeleted = 0
						AND isDisabled = 0
				), 0),
				polls = (
					SELECT	COUNT(*)
					FROM	wbb".WBB_N."_post
					WHERE 	threadID = thread.threadID
						AND pollID <> 0
						AND isDeleted = 0
						AND isDisabled = 0
				),
				firstPostID = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		postID
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
						ORDER BY	time
					", 1)."
				), 0),
				time = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		time
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
						ORDER BY	time
					", 1)."
				), 0),
				userID = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		userID
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
						ORDER BY	time
					", 1)."
				), 0),
				username = IFNULL((
					".WCF::getDB()->handleLimitParameter("
						SELECT		username
						FROM		wbb".WBB_N."_post
						WHERE		threadID = thread.threadID
						ORDER BY	time
					", 1)."
				), '')
			WHERE	thread.threadID IN (0".$threadIDs.")";
		WCF::getDB()->sendQuery($sql);
		$this->executed();
		
		$this->calcProgress(($this->limit * $this->loop), $count);
		$this->nextLoop();
	}
}
?>