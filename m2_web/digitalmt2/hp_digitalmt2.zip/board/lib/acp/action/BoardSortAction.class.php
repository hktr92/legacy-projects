<?php
require_once(WBB_DIR.'lib/data/board/Board.class.php');
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');
require_once(WCF_DIR.'lib/system/exception/IllegalLinkException.class.php');

/**
 * Sorts the structure of boards.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.acp.action
 */
class BoardSortAction extends AbstractAction {
	public $positions = array();
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_POST['positions']) && is_array($_POST['positions'])) $this->positions = $_POST['positions'];
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// check permission
		WCF::getUser()->checkPermission('admin.board.canEditBoard');
				
		// delete old positions
		$sql = "TRUNCATE wbb".WBB_N."_board_structure";
		WCF::getDB()->sendQuery($sql);
		
		// inserts new positions
		$inserts = '';
		foreach ($this->positions as $boardID => $positions) {
			$boardID = intval($boardID);
			// check board id
			try {
				$board = Board::getBoard($boardID);
			}
			catch (IllegalLinkException $e) {
				continue;
			}
			
			foreach ($positions as $parentID => $position) {
				$parentID = intval($parentID);
				$position = intval($position);
				
				if (!empty($inserts)) $inserts .= ',';
				$inserts .= "(".$parentID.", ".$boardID.", ".$position.")";
			}
		}
		
		// delete old positions
		$sql = "TRUNCATE wbb".WBB_N."_board_structure";
		WCF::getDB()->sendQuery($sql);
		
		// insert new positions
		if (!empty($inserts)) {
			$sql = "REPLACE INTO	wbb".WBB_N."_board_structure
						(parentID, boardID, position)
				VALUES		".$inserts;
			WCF::getDB()->sendQuery($sql);
		}
		
		// insert default values
		$sql = "INSERT IGNORE INTO	wbb".WBB_N."_board_structure
						(parentID, boardID)
			SELECT			parentID, boardID
			FROM			wbb".WBB_N."_board";
		WCF::getDB()->sendQuery($sql);
				
		// reset cache
		WCF::getCache()->clearResource('board');
		$this->executed();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=BoardList&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>