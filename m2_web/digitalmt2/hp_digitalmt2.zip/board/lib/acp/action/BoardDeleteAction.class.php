<?php
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

/**
 * Deletes a board.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.acp.action
 */
class BoardDeleteAction extends AbstractAction {
	public $boardID = 0;
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['boardID'])) $this->boardID = intval($_REQUEST['boardID']);
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// check permission
		WCF::getUser()->checkPermission('admin.board.canDeleteBoard');
				
		// delete board
		require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
		$board = new BoardEditor($this->boardID);	
		$board->delete();
		WCF::getCache()->clearResource('board');
		$this->executed();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=BoardList&deletedBoardID='.$this->boardID.'&packageID='.PACKAGE_ID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>