<?php
// wbb imports
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostAction.class.php');
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
require_once(WBB_DIR.'lib/form/ThreadAddForm.class.php');

/**
 * Shows the edit post form.
 *
 * @author	Michael Schaefer
 * @copyright	2001-2010 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	form
 * @category 	Burning Board
 */
class PostEditForm extends ThreadAddForm {
	// system
	public $templateName = 'postEdit';
	
	/**
	 * post id
	 * 
	 * @var	integer
	 */
	public $postID = 0;
	
	/**
	 * post editor object
	 * 
	 * @var	PostEditor
	 */
	public $post = null;
	
	/**
	 * thread editor object
	 * 
	 * @var	ThreadEditor
	 */
	public $thread;
	
	/**
	 * list of attachments
	 * 
	 * @var	array
	 */
	public $attachments = array();
	
	public $isModerator = false;
	public $isAuthor = false;
	public $canEditPost = false;
	public $canDeletePost = false;
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		MessageForm::readParameters();
		
		if (isset($_REQUEST['postID'])) $this->postID = intval($_REQUEST['postID']);
		
		$this->post = new PostEditor($this->postID);
		$this->thread = new ThreadEditor($this->post->threadID);
		if (!$this->thread->threadID) {
			throw new IllegalLinkException();
		}
		$this->board = new BoardEditor($this->thread->boardID);
		
		$this->thread->enter($this->board);
		
		// check permissions (TODO: maybe we can use post->canEditPost() here)
		$this->isModerator = WCF::getUser()->getPermission('mod.board.canEditPost') || WCF::getUser()->getPermission('mod.board.canDeletePostCompletely');
		$this->isAuthor = $this->post->userID && $this->post->userID == WCF::getUser()->userID;
		
		$this->canEditPost = WCF::getUser()->getPermission('mod.board.canEditPost') || $this->isAuthor && $this->board->getPermission('canEditOwnPost');
		$this->canDeletePost = WCF::getUser()->getPermission('mod.board.canDeletePostCompletely') || $this->isAuthor && $this->board->getPermission('canDeleteOwnPost');

		if ((!$this->canEditPost && !$this->canDeletePost) || (!$this->isModerator && ($this->board->isClosed || $this->thread->isClosed || $this->post->isClosed))) {
			throw new PermissionDeniedException();
		}
	}
	
	/**
	 * @see Form::submit()
	 */
	public function submit() {
		parent::submit();
		
		try {
			if (isset($_POST['deletePost'])) {
				if (!$this->canDeletePost()) {
					throw new PermissionDeniedException();
				}
				
				if (isset($_POST['sure'])) {
					$postAction = new PostAction($this->board, $this->thread, $this->post);
					$postAction->delete(true);
				}
				else {
					throw new UserInputException('sure');
				}
			}
		}
		catch (UserInputException $e) {
			$this->errorField = $e->getField();
			$this->errorType = $e->getType();
		}
	}
	
	/**
	 * Does nothing.
	 */
	protected function validateSubject() {}
	
	/**
	 * @see Form::save()
	 */
	public function save() {
		if (!$this->canEditPost()) {
			throw new PermissionDeniedException();
		}

		MessageForm::save();
		
		// save poll
		if ($this->showPoll) {
			$this->pollEditor->save();
		}
		
		// update database entry
		$this->post->update($this->subject, $this->text, $this->getOptions(), $this->attachmentListEditor, $this->pollEditor);
		
		$threadData = array();
		if ($this->thread->firstPostID == $this->post->postID) {
			// update thread topic
			if (!empty($this->subject)) $threadData['topic'] = $this->subject;
		}
		
		// update thread
		$this->thread->update($threadData);
		
		// update last posts
		if ($this->thread->firstPostID == $this->post->postID) {
			$this->board->setLastPosts();
			WCF::getCache()->clearResource('boardData');
		}
		$this->saved();
		
		// forward to post
		$url = 'index.php?page=Thread&postID='.$this->postID. SID_ARG_2ND_NOT_ENCODED . '#post'.$this->postID;
		HeaderUtil::redirect($url);
		exit;
	}
	
	/**
	 * @see MessageForm::saveOptions()
	 */
	protected function saveOptions() {
		if (WCF::getUser()->userID) {
			$options = array();
			
			// wysiwyg
			$options['wysiwygEditorMode'] = $this->wysiwygEditorMode;
			$options['wysiwygEditorHeight'] = $this->wysiwygEditorHeight;
			
			// options
			if (WCF::getUser()->getPermission('user.'.$this->permissionType.'.canUseBBCodes')) {
				$options[$this->permissionType.'ParseURL'] = $this->parseURL;
			}
			
			$editor = WCF::getUser()->getEditor();
			$editor->updateOptions($options);
		}
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();

		if (!count($_POST)) {
			$this->text = $this->post->message;
			$this->subject = $this->post->subject;
			
			$this->enableSmilies =  $this->post->enableSmilies;
			$this->enableHtml = $this->post->enableHtml;
			$this->enableBBCodes = $this->post->enableBBCodes;
		}
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'postID' =>  $this->postID,
			'thread' => $this->thread,
			'form' => $this,
			'post' => $this->post
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		$this->attachmentListEditor = new MessageAttachmentListEditor(array($this->postID), 'post', PACKAGE_ID, WCF::getUser()->getPermission('user.board.maxAttachmentSize'), WCF::getUser()->getPermission('user.board.allowedAttachmentExtensions'), WCF::getUser()->getPermission('user.board.maxAttachmentCount'));
		$this->pollEditor = new PollEditor($this->post->pollID, 0, 'post', WCF::getUser()->getPermission('user.board.canStartPublicPoll'));
		
		parent::show();
	}
	
	/**
	 * Returns true, if the active user can edit this post.
	 */
	public function canEditPost() {
		return $this->canEditPost;
	}
	
	/**
	 * Returns true, if the active user can delete this post.
	 */
	public function canDeletePost() {
		return $this->canDeletePost;
	}
}
?>