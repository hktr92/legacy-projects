<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');

// wcf imports
require_once(WCF_DIR.'lib/data/attachment/MessageAttachmentListEditor.class.php');
require_once(WCF_DIR.'lib/data/message/poll/PollEditor.class.php');
require_once(WCF_DIR.'lib/form/MessageForm.class.php');


/**
 * Shows the new thread form.
 *
 * @author 	Marcel Werk
 * @copyright	2001-2010 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	form
 * @category 	Burning Board
 */
class ThreadAddForm extends MessageForm {
	public $showSignatureSetting = false;
	public $maxTextLength = 10000;
	
	/**
	 * board id
	 * 
	 * @var	integer
	 */
	public $boardID = 0;
	
	/**
	 * board editor object
	 * 
	 * @var	BoardEditor
	 */
	public $board = null;
	
	/**
	 * attachment list editor object
	 * 
	 * @var	MessageAttachmentListEditor
	 */
	public $attachmentListEditor = null;
	
	/**
	 * poll editor object
	 * 
	 * @var	PollEditor
	 */
	public $pollEditor = null;
	
	/**
	 * thread editor object
	 * 
	 * @var	ThreadEditor
	 */
	public $newThread = null;
	
	public $templateName = 'threadAdd';
	public $useCaptcha = POST_ADD_USE_CAPTCHA;
	
	// form parameters
	public $username = '';
	public $preview, $send;
	public $boardIDs = array();
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		// get board
		if (isset($_REQUEST['boardID'])) $this->boardID = intval($_REQUEST['boardID']);
		$this->board = new BoardEditor($this->boardID);
		$this->board->enter();
		
		// check permissions
		if (!$this->board->canStartThread()) {
			throw new PermissionDeniedException();
		}
		
		$this->messageTable = "wbb".WBB_N."_post";
	}

	/**
	 * @see Form::readFormParameters()
	 */
	public function readFormParameters() {
		parent::readFormParameters();
		
		if (isset($_POST['username'])) 		$this->username 	= StringUtil::trim($_POST['username']);
		if (isset($_POST['preview']))		$this->preview		= (boolean) $_POST['preview'];
		if (isset($_POST['send']))		$this->send		= (boolean) $_POST['send'];
		if (isset($_POST['boardIDs']))		$this->boardIDs		= ArrayUtil::toIntegerArray($_POST['boardIDs']);
	}
	
	/**
	 * @see Form::submit()
	 */
	public function submit() {
		// call submit event
		EventHandler::fireAction($this, 'submit');
		
		$this->readFormParameters();
		
		try {
			// attachment handling
			if ($this->showAttachments) {
				$this->attachmentListEditor->handleRequest();
			}
			
			// poll handling
			if ($this->showPoll) {
				$this->pollEditor->readParams();
			}
				
			// preview
			if ($this->preview) {
				require_once(WCF_DIR.'lib/data/message/bbcode/AttachmentBBCode.class.php');
				AttachmentBBCode::setAttachments($this->attachmentListEditor->getSortedAttachments());
				WCF::getTPL()->assign('preview', PostEditor::createPreview($this->subject, $this->text, $this->enableSmilies, $this->enableHtml, $this->enableBBCodes));
			}
			// send message or save as draft
			if ($this->send) {
				$this->validate();
				// no errors
				$this->save();
			}
		}
		catch (UserInputException $e) {
			$this->errorField = $e->getField();
			$this->errorType = $e->getType();
		}
	}
	
	/**
	 * @see Form::validate()
	 */
	public function validate() {
		// subject, text, captcha
		parent::validate();
		
		// username
		$this->validateUsername();
		
		// poll
		if ($this->showPoll) $this->pollEditor->checkParams();
	}
	
	/**
	 * Validates the username.
	 */
	protected function validateUsername() {
		// only for guests
		if (WCF::getUser()->userID == 0) {
			// username
			if (empty($this->username)) {
				throw new UserInputException('username');
			}
			if (!UserUtil::isValidUsername($this->username)) {
				throw new UserInputException('username', 'notValid');
			}
			if (!UserUtil::isAvailableUsername($this->username)) {
				throw new UserInputException('username', 'notAvailable');
			}
			
			WCF::getSession()->setUsername($this->username);
		}
		else {
			$this->username = WCF::getUser()->username;
		}
	}
	
	/**
	 * @see Form::save()
	 */
	public function save() {
		parent::save();
		
		// search for double posts
		if ($postID = PostEditor::test($this->subject, $this->text, WCF::getUser()->userID, $this->username)) {
			HeaderUtil::redirect('index.php?page=Thread&postID=' . $postID . SID_ARG_2ND_NOT_ENCODED . '#post' . $postID);
			exit;
		}
		
		// save poll
		if ($this->showPoll) {
			$this->pollEditor->save();
		}
		
		// save thread in database
		$this->newThread = ThreadEditor::create($this->board->boardID, 0, '', $this->subject, $this->text, WCF::getUser()->userID, $this->username, 0, 0, 0, $this->getOptions(), 0, $this->attachmentListEditor, $this->pollEditor);
		
		// update user posts
		if (WCF::getUser()->userID && $this->board->countUserPosts) {
			require_once(WBB_DIR.'lib/data/user/WBBUser.class.php');
			WBBUser::updateUserPosts(WCF::getUser()->userID, 1);
			if (ACTIVITY_POINTS_PER_THREAD) {
				require_once(WCF_DIR.'lib/data/user/rank/UserRank.class.php');
				UserRank::updateActivityPoints(ACTIVITY_POINTS_PER_THREAD);
			}
		}
		
		// refresh counter and last post
		$this->board->addThreads();
		$this->board->setLastPost($this->newThread);
		
		// reset stat cache
		WCF::getCache()->clearResource('stat');
		WCF::getCache()->clearResource('boardData');
		
		// send notifications
		$this->saved();
		
		// forward to post
		HeaderUtil::redirect('index.php?page=Thread&threadID=' . $this->newThread->threadID . SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
	
	/**
	 * @see Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		if (!count($_POST)) {
			// default values
			$this->username = WCF::getSession()->username;
		}
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'username' => $this->username,
			'board' => $this->board,
			'boardID' => $this->board->boardID,
			'postID' => 0,
			'boardIDs' => $this->boardIDs
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		if (MODULE_POLL != 1 || !$this->board->getPermission('canStartPoll')) {
			$this->showPoll = false;
		}
		
		if (MODULE_ATTACHMENT != 1 || !$this->board->getPermission('canUploadAttachment')) {
			$this->showAttachments = false;
		}
		
		// get attachments editor
		if ($this->attachmentListEditor == null) {
			$this->attachmentListEditor = new MessageAttachmentListEditor(array(), 'post', PACKAGE_ID, WCF::getUser()->getPermission('user.board.maxAttachmentSize'), WCF::getUser()->getPermission('user.board.allowedAttachmentExtensions'), WCF::getUser()->getPermission('user.board.maxAttachmentCount'));
		}
		
		// get poll editor
		if ($this->pollEditor == null) $this->pollEditor = new PollEditor(0, 0, 'post', WCF::getUser()->getPermission('user.board.canStartPublicPoll'));
		
		// show form
		parent::show();
	}
}
?>