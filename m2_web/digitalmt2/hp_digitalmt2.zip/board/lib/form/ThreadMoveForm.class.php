<?php
// wbb imports
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');

// wcf imports
require_once(WCF_DIR.'lib/form/AbstractForm.class.php');

/**
 * Moves a thread.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.form
 */
class ThreadMoveForm extends AbstractForm {
	public $templateName = 'threadMove';
	
	public $threadID = 0;
	public $boardID = 0;
	public $thread, $board, $newBoard;
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['threadID'])) $this->threadID = intval($_REQUEST['threadID']);
		$this->thread = new ThreadEditor($this->threadID);
		if (!$this->thread->threadID) {
			throw new IllegalLinkException();
		}
		$this->board = new BoardEditor($this->thread->boardID);
		$this->board->enter();
		$this->boardID = $this->board->boardID;
	}
	
	/**
	 * @see Form::readFormParameters()
	 */
	public function readFormParameters() {
		parent::readFormParameters();
		
		if (isset($_POST['boardID'])) $this->boardID = intval($_POST['boardID']);
	}
	
	/**
	 * @see Form::validate()
	 */
	public function validate() {
		parent::validate();
		
		if (!$this->boardID) {
			throw new UserInputException('boardID');
		}
		
		try {
			$this->newBoard = new BoardEditor($this->boardID);
		}
		catch (IllegalLinkException $e) {
			throw new UserInputException('boardID');
		}
		
		if ($this->newBoard->boardID == $this->thread->boardID || !$this->newBoard->isBoard()) {
			throw new UserInputException('boardID');
		}
	}
	
	/**
	 * @see Form::save()
	 */
	public function save() {
		parent::save();
		
		// move thread
		require_once(WBB_DIR.'lib/data/thread/ThreadAction.class.php');
		$threadAction = new ThreadAction($this->newBoard, $this->thread);
		$threadAction->move();
		$this->saved();
		
		// forward
		HeaderUtil::redirect('index.php?page=Thread&threadID='.$this->threadID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'boardOptions' => Board::getBoardSelect(array(), true, true),
			'threadID' => $this->threadID,
			'thread' => $this->thread,
			'boardID' => $this->boardID,
			'board' => $this->board
		));
	}
	
	/**
	 * @see Page::show()
	 */
	public function show() {
		// check permission
		WCF::getUser()->checkPermission('mod.board.canCloseThread');

		parent::show();
	}
}
?>