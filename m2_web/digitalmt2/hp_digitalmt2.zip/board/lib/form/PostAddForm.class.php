<?php
// wbb imports
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
require_once(WBB_DIR.'lib/form/ThreadAddForm.class.php');

/**
 * Shows the thread reply form.
 *
 * @package	com.woltlab.wbb.form
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class PostAddForm extends ThreadAddForm {
	public $threadID = 0;
	public $postID = 0;
	public $thread;
	public $templateName = 'postAdd';
	public $action = '';
	public $newPost;
	
	/**
	 * @see Page::readParameters()
	 */
	public function readParameters() {
		MessageForm::readParameters();
		
		if (isset($_REQUEST['threadID'])) $this->threadID = intval($_REQUEST['threadID']);
		if (isset($_REQUEST['postID'])) $this->postID = intval($_REQUEST['postID']);
		if (isset($_REQUEST['action'])) $this->action = $_REQUEST['action'];
		
		// get thread
		$this->thread = new ThreadEditor($this->threadID, null, $this->postID);
		$this->threadID = $this->thread->threadID;
		
		// get board
		$this->board = new BoardEditor($this->thread->boardID);
		
		// check permissions
		$this->thread->enter($this->board);
		if (!$this->thread->canReplyThread($this->board)) {
			throw new PermissionDeniedException();
		}
		
		$this->messageTable = "wbb".WBB_N."_post";
	}
	
	/**
	 * Does nothing.
	 */
	protected function validateSubject() {}
	
	/**
	 * Does nothing.
	 */
	protected function validatePrefix() {}
	
	/**
	 * @see Form::save()
	 */
	public function save() {
		MessageForm::save();
		
		// search for double posts
		if ($postID = PostEditor::test($this->subject, $this->text, WCF::getUser()->userID, $this->username, $this->threadID)) {
			HeaderUtil::redirect('index.php?page=Thread&postID=' . $postID . SID_ARG_2ND_NOT_ENCODED . '#post' . $postID);
			exit;
		}
		
		// save poll
		if ($this->showPoll) {
			$this->pollEditor->save();
		}
		
		// save post in database
		$this->newPost = PostEditor::create($this->thread->threadID, $this->subject, $this->text, WCF::getUser()->userID, $this->username, $this->getOptions(), $this->attachmentListEditor, $this->pollEditor);
		
		// refresh thread
		$this->thread->addPost($this->newPost);
		
		// update user posts
		if (WCF::getUser()->userID && $this->board->countUserPosts) {
			require_once(WBB_DIR.'lib/data/user/WBBUser.class.php');
			WBBUser::updateUserPosts(WCF::getUser()->userID, 1);
			if (ACTIVITY_POINTS_PER_POST) {
				require_once(WCF_DIR.'lib/data/user/rank/UserRank.class.php');
				UserRank::updateActivityPoints(ACTIVITY_POINTS_PER_POST);
			}
		}
		
		// refresh counter and last post
		$this->board->addPosts();
		$this->board->setLastPost($this->thread);
		
		// reset stat cache
		WCF::getCache()->clearResource('stat');
		WCF::getCache()->clearResource('boardData');
		$this->saved();
		
		// forward to post
		$url = 'index.php?page=Thread&postID='.$this->newPost->postID. SID_ARG_2ND_NOT_ENCODED . '#post'.$this->newPost->postID;
		HeaderUtil::redirect($url);
		exit;
	}
	
	/**
	 * @see	Page::readData()
	 */
	public function readData() {
		parent::readData();
		
		// default values
		if (!count($_POST)) {
			// single quote
			if ($this->action == 'quote') {
				$post = $this->thread->getPost();
				if ($post) {
					$this->text = "[quote='".StringUtil::replace("'", "\'", $post->username)."',index.php?page=Thread&postID=".$post->postID."#post".$post->postID."]".$post->message."[/quote]";
					if ($post->subject) {
						$this->subject = WCF::getLanguage()->get('wbb.postAdd.quote.subject', array('$subject' => $post->subject));
					}
				}
			}
		}
	}
	
	/**
	 * @see Page::assignVariables()
	 */
	public function assignVariables() {
		parent::assignVariables();
		
		WCF::getTPL()->assign(array(
			'postID' =>  $this->postID,
			'thread' => $this->thread,
			'form' => $this
		));
	}
}
?>