<?php
// wcf imports
require_once(WCF_DIR.'lib/data/user/avatar/Gravatar.class.php');
require_once(WCF_DIR.'lib/data/user/avatar/Avatar.class.php');

// wbb imports
require_once(WBB_DIR.'lib/data/user/AbstractWBBUserSession.class.php');

/**
 * Represents a user session in the forum.
 *
 * @author 	Marcel Werk
 * @copyright	2001-2010 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	data.user
 * @category 	Burning Board
 */
class WBBUserSession extends AbstractWBBUserSession {
	protected $boardVisits;
	protected $ignores = null;
	protected $outstandingNotifications = null;
	protected $invitations = null;
	
	/**
	 * displayable avatar object.
	 *
	 * @var DisplayableAvatar
	 */
	protected $avatar = null;
	
	/**
	 * @see UserSession::__construct()
	 */
	public function __construct($userID = null, $row = null, $username = null) {
		$this->sqlSelects .= "	wbb_user.*, avatar.*, wbb_user.userID AS wbbUserID,
					GROUP_CONCAT(DISTINCT whitelist.whiteUserID ORDER BY whitelist.whiteUserID ASC SEPARATOR ',') AS buddies,
					GROUP_CONCAT(DISTINCT blacklist.blackUserID ORDER BY blacklist.blackUserID ASC SEPARATOR ',') AS ignoredUser,
					(SELECT COUNT(*) FROM wcf".WCF_N."_user_whitelist WHERE whiteUserID = user.userID AND confirmed = 0 AND notified = 0) AS numberOfInvitations,";
		$this->sqlJoins .= " 	LEFT JOIN wbb".WBB_N."_user wbb_user ON (wbb_user.userID = user.userID)
					LEFT JOIN wcf".WCF_N."_user_whitelist whitelist ON (whitelist.userID = user.userID)
					LEFT JOIN wcf".WCF_N."_user_blacklist blacklist ON (blacklist.userID = user.userID)
					LEFT JOIN wcf".WCF_N."_avatar avatar ON (avatar.avatarID = user.avatarID) ";
		parent::__construct($userID, $row, $username);
	}
	
	/**
	 * @see User::handleData()
	 */
	protected function handleData($data) {
		parent::handleData($data);
		
		if (MODULE_AVATAR == 1 && !$this->disableAvatar && $this->showAvatar) {
			if (MODULE_GRAVATAR == 1 && $this->gravatar) {
				$this->avatar = new Gravatar($this->gravatar);
			}
			else if ($this->avatarID) {
				$this->avatar = new Avatar(null, $data);
			}
		}
	}
	
	/**
	 * Updates the user session.
	 */
	public function update() {
		// update global last activity timestamp
		WBBUserSession::updateLastActivityTime($this->userID);
		
		if (!$this->wbbUserID) {
			// define default values
			$this->data['boardLastVisitTime'] = (TIME_NOW - 86400 * 7);
			$this->data['boardLastActivityTime'] = TIME_NOW;
			
			// create wbb user record
			$sql = "INSERT IGNORE INTO	wbb".WBB_N."_user
							(userID, boardLastVisitTime, boardLastActivityTime)
				VALUES			(".$this->userID.", ".$this->boardLastVisitTime.", ".$this->boardLastActivityTime.")";
			WCF::getDB()->registerShutdownUpdate($sql);
		}
		else {
			WBBUserSession::updateBoardLastActivityTime($this->userID);
		}
		
		$this->getBoardVisits();
	}
	
	/**
	 * Initialises the user session.
	 */
	public function init() {
		parent::init();
		
		$this->invitations = $this->ignores = $this->outstandingNotifications = null;
	}
	
	/**
	 * @see UserSession::getGroupData()
	 */
	protected function getGroupData() {
		parent::getGroupData();
		
		// get user permissions (board_to_user)
		$userPermissions = array();
		$sql = "SELECT		*
			FROM		wbb".WBB_N."_board_to_user
			WHERE		userID = ".$this->userID;
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray()) {
			$boardID = $row['boardID'];
			unset($row['boardID'], $row['userID']);
			$userPermissions[$boardID] = $row;
		}
		
		if (count($userPermissions)) {
			require_once(WBB_DIR.'lib/data/board/Board.class.php');
			Board::inheritPermissions(0, $userPermissions);
		
			foreach ($userPermissions as $boardID => $row) {
				foreach ($row as $key => $val) {
					if ($val != -1) {
						$this->boardPermissions[$boardID][$key] = $val;
					}
				}
			}
		}
	}
	
	/**
	 * Returns true, if the active user ignores the given user.
	 * 
	 * @return	boolean
	 */
	public function ignores($userID) {
		if ($this->ignores === null) {
			if ($this->ignoredUser) {
				$this->ignores = explode(',', $this->ignoredUser);
			}
			else {
				$this->ignores = array();
			}
		}
		
		return in_array($userID, $this->ignores);
	}
	
	/**
	 * Sets the global board last visit timestamp.
	 */
	public function setLastVisitTime($timestamp) {
		$this->data['boardLastVisitTime'] = $timestamp;
		//$this->data['boardLastActivityTime'] = TIME_NOW;
		
		$sql = "UPDATE	wbb".WBB_N."_user
			SET	boardLastVisitTime = ".$timestamp.",
				boardLastActivityTime = ".TIME_NOW."
			WHERE	userID = ".$this->userID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Sets the last mark all as read timestamp.
	 */
	public function setLastMarkAllAsReadTime($timestamp) {
		$this->data['boardLastMarkAllAsReadTime'] = $timestamp;
		
		$sql = "UPDATE	wbb".WBB_N."_user
			SET	boardLastMarkAllAsReadTime = ".$timestamp."
			WHERE	userID = ".$this->userID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Loads the board visits of this user from database.
	 */
	protected function getBoardVisits() {
		$this->boardVisits = array();
		
		$sql = "SELECT	boardID, lastVisitTime
			FROM 	wbb".WBB_N."_board_visit
			WHERE 	userID = ".$this->userID;
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$this->boardVisits[$row['boardID']] = $row['lastVisitTime'];
		}
	}
	
	/**
	 * Returns the board visit of this user for the board with the given board id.
	 * 
	 * @param	integer		$boardID
	 * @return	integer		board visit of this user for the board with the given board id
	 */
	public function getBoardVisitTime($boardID) {
		$boardVisitTime = 0;
		if (isset($this->boardVisits[$boardID])) $boardVisitTime = $this->boardVisits[$boardID];
		
		if ($boardVisitTime < $this->getLastMarkAllAsReadTime()) {
			$boardVisitTime = $this->getLastMarkAllAsReadTime();
		}
		
		return $boardVisitTime;
	}
	
	/**
	 * Returns the last visit time of this user.
	 * 
	 * @return	integer
	 */
	public function getLastVisitTime() {
		return intval($this->boardLastVisitTime) - VISIT_TIME_FRAME;
	}
	
	/**
	 * Sets the board visit of this user for the board with the given board id.
	 *
	 * @param	integer		$boardID
	 */
	public function setBoardVisitTime($boardID) {
		$sql = "REPLACE INTO	wbb".WBB_N."_board_visit
					(userID, boardID, lastVisitTime)
			VALUES		(".$this->userID.",
					".$boardID.",
					".TIME_NOW.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		WCF::getSession()->resetUserData();
		
		$this->boardVisits[$boardID] = TIME_NOW;
	}
	
	/**
	 * Sets the thread visit of this user for the thread with the given thread id.
	 *
	 * @param	integer		$threadID
	 */
	public function setThreadVisitTime($threadID, $timestamp = TIME_NOW) {
		$sql = "REPLACE INTO	wbb".WBB_N."_thread_visit
					(userID, threadID, lastVisitTime)
			VALUES 		(".$this->userID.",
					".$threadID.",
					".$timestamp.")";
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Updates the global last activity timestamp in user database.
	 * 
	 * @param	integer		$userID
	 * @param	integer		$timestamp
	 */
	public static function updateLastActivityTime($userID, $timestamp = TIME_NOW) {
		// update lastActivity in wcf user table
		$sql = "UPDATE	wcf".WCF_N."_user
			SET	lastActivityTime = ".$timestamp."
			WHERE	userID = ".$userID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Updates the board last activity timestamp in user database.
	 * 
	 * @param	integer		$userID
	 * @param	integer		$timestamp
	 */
	public static function updateBoardLastActivityTime($userID, $timestamp = TIME_NOW) {
		// update boardLastActivity in wbb user table
		$sql = "UPDATE	wbb".WBB_N."_user
			SET	boardLastActivityTime = ".$timestamp."
			WHERE	userID = ".$userID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Returns the last mark all as read timestamp.
	 * 
	 * @return	integer
	 */
	public function getLastMarkAllAsReadTime() {
		return $this->boardLastMarkAllAsReadTime;
	}
	
	/**
	 * @see	PM::getOutstandingNotifications()
	 */
	public function getOutstandingNotifications() {
		if ($this->outstandingNotifications === null) {
			require_once(WCF_DIR.'lib/data/message/pm/PM.class.php');
			$this->outstandingNotifications = PM::getOutstandingNotifications(WCF::getUser()->userID);
		}
		
		return $this->outstandingNotifications;
	}
	
	/**
	 * @see	PM::getOutstandingNotifications()
	 */
	public function getInvitations() {
		if ($this->invitations === null) {
			$this->invitations = array();
			$sql = "SELECT		user_table.userID, user_table.username
				FROM		wcf".WCF_N."_user_whitelist whitelist
				LEFT JOIN	wcf".WCF_N."_user user_table
				ON		(user_table.userID = whitelist.userID)
				WHERE		whitelist.whiteUserID = ".$this->userID."
						AND whitelist.confirmed = 0
						AND whitelist.notified = 0
				ORDER BY	whitelist.time";
			$result = WCF::getDB()->sendQuery($sql);
			while ($row = WCF::getDB()->fetchArray($result)) {
				$this->invitations[] = new User(null, $row);
			}
		}
		
		return $this->invitations;
	}
	
	/**
	 * Returns the avatar of this user.
	 * 
	 * @return	DisplayableAvatar
	 */
	public function getAvatar() {
		return $this->avatar;
	}
}
?>