<?php
// wcf imports
require_once(WCF_DIR.'lib/system/session/UserSession.class.php');

/**
 * Abstract class for wbb user and guest sessions.
 *
 * @package	com.woltlab.wbb.data.user
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class AbstractWBBUserSession extends UserSession {
	protected $boardPermissions = array();
	
	/**
	 * Checks whether this user has the permission with the given name on the board with the given board id.
	 * 
	 * @param	string		$permission	name of the requested permission
	 * @param	integer		$boardID
	 * @return	mixed				value of the permission
	 */
	public function getBoardPermission($permission, $boardID) {
		if (isset($this->boardPermissions[$boardID][$permission])) {
			return $this->boardPermissions[$boardID][$permission];
		}
		return $this->getPermission('user.board.'.$permission);
	}
	
	/**
	 * @see UserSession::getGroupData()
	 */
	protected function getGroupData() {
		parent::getGroupData();
		
		// get group permissions from cache (board_to_group)
		$groups = implode(",", $this->groupIDs);
		$groupsFileName = StringUtil::getHash(implode("-", $this->groupIDs));
		
		// register cache resource
		WCF::getCache()->addResource('boardPermissions-'.$groups, WBB_DIR.'cache/cache.boardPermissions-'.$groupsFileName.'.php', WBB_DIR.'lib/system/cache/CacheBuilderBoardPermissions.class.php');
		
		// get group data from cache
		$this->boardPermissions = WCF::getCache()->get('boardPermissions-'.$groups);
		if (isset($this->boardPermissions['groupIDs']) && $this->boardPermissions['groupIDs'] != $groups) {
			$this->boardPermissions = array();
		}
	}
}
?>