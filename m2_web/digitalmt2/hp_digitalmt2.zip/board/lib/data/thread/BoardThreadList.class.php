<?php
require_once(WBB_DIR.'lib/data/thread/ThreadList.class.php');

/**
 * BoardThreadList provides extended functions for displaying a list of threads.
 * 
 * @package	com.woltlab.wbb.data.thread
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class BoardThreadList extends ThreadList {
	// parameters
	public $board;
	
	// data
	public $maxLastPostTime = 0;
	
	/**
	 * Creates a new BoardThreadList object.
	 */
	public function __construct(Board $board) {
		$this->board = $board;
		
		parent::__construct();
	}
	
	/**
	 * @see ThreadList::initDefaultSQL()
	 */
	protected function initDefaultSQL() {
		parent::initDefaultSQL();
		
		$this->sqlConditions = "boardID = ".$this->board->boardID;
	}
	
	/**
	 * @see ThreadList::readThreads()
	 */
	public function readThreads() {
		parent::readThreads();
		
		foreach ($this->threads as $key => $thread) {
			if ($thread->lastPostTime > $this->maxLastPostTime) {
				$this->maxLastPostTime = $thread->lastPostTime;
			}
		}
	}
}
?>