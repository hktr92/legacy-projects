<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');

// wcf imports
require_once(WCF_DIR.'lib/data/DatabaseObject.class.php');

/**
 * Represents a thread in the forum.
 * 
 * @package	com.woltlab.wbb.data.thread
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class Thread extends DatabaseObject {
	protected $post;
	protected $board = null;
	
	/**
	 * Creates a new thread object.
	 *
	 * If id is set, the function reads the thread data from database.
	 * Otherwise it uses the given resultset.
	 * 
	 * @param 	integer 	$threadID	id of a thread
	 * @param 	array 		$row		resultset with thread data form database
	 * @param	integer		$postID		id of a post in the requested thread
	 */
	public function __construct($threadID, $row = null, $postID = null) {
		if ($postID !== null && $postID !== 0) {
			require_once(WBB_DIR.'lib/data/post/Post.class.php');
			$this->post = new Post($postID);
			if ($this->post->threadID) {
				$threadID = $this->post->threadID;
			}
		}
		
		if ($threadID !== null) {
			// select thread and thread subscription, visit and rating 
			$sql = "SELECT		thread.* 
						".(WCF::getUser()->userID ? ', thread_visit.lastVisitTime' : '')."
				FROM 		wbb".WBB_N."_thread thread
				".((WCF::getUser()->userID) ? ("
				LEFT JOIN 	wbb".WBB_N."_thread_visit thread_visit 
				ON 		(thread_visit.threadID = thread.threadID
						AND thread_visit.userID = ".WCF::getUser()->userID.")") : (""))."
				WHERE 		thread.threadID = ".$threadID;
			$row = WCF::getDB()->getFirstRow($sql);
		}

		parent::__construct($row);
	}

	/**
	 * Returns the requested post, if post id was given at creation of the Thread object.
	 * 
	 * @return	boolean		requested post, if post id was given at creation of the Thread object
	 */
	public function getPost() {
		return $this->post;
	}
	
	/**
	 * Enters the active user to this thread.
	 */
	public function enter($board = null, $refreshSession = true) {
		if (!$this->threadID || $this->movedThreadID) {
			throw new IllegalLinkException();
		}
		
		if ($board == null || $board->boardID != $this->boardID) {
			$board = Board::getBoard($this->boardID);
		}
		
		$board->enter();
		
		// check permissions
		if (!$board->getPermission('canReadThread')) {
			throw new PermissionDeniedException();
		}
		
		// save board
		$this->board = $board;
	}
	
	/**
	 * Returns true, if the active user can reply this thread.
	 */
	public function canReplyThread($board = null) {
		if ($board == null || $board->boardID != $this->boardID) {
			if ($this->board !== null) $board = $this->board;
			else $board = Board::getBoard($this->boardID);
		}
		return (!$board->isClosed && !$this->isClosed && $board->getPermission('canReplyThread'));
	}
	
}
?>