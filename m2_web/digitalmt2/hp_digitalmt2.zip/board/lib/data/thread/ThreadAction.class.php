<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
/**
 * Executes moderation actions on threads.
 * 
 * @package	com.woltlab.wbb.data.thread
 * @author	Michael Schaefer
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class ThreadAction {
	protected $boardID = 0;
	protected $threadID = 0;
	protected $topic = '';
	protected $url = '';
	protected $threadIDs = null;
	protected $postIDs = null;
	protected $board = null;
	protected $thread = null;
	
	/**
	 * Creates a new ThreadAction object.
	 * 
	 * @param	BoardEditor	$board
	 * @param	ThreadEditor	$thread
	 * @param	PostEditor	$post
	 */
	public function __construct($board = null, $thread = null, $post = null, $threadID = 0, $topic = '', $forwardURL = '') {
		$this->board = $board;
		$this->thread = $thread;
		$this->post = $post;
		if ($threadID != 0) $this->threadID = $threadID;
		else if ($thread) $this->threadID = $thread->threadID;
		if ($board) $this->boardID = $board->boardID;
		$this->topic = $topic;
		$this->url = $forwardURL;
		if (empty($this->url)) $this->url = 'index.php?page=Board&boardID='.$this->boardID.SID_ARG_2ND_NOT_ENCODED;
	}
	
	/**
	 * Trashes the selected thread.
	 */
	public function trash() {
		if (!false || !WCF::getUser()->getPermission('mod.board.canDeleteThread')) {
			return;
		}
		
		if ($this->thread != null && !$this->thread->isDeleted) {
			$this->thread->trash();
			$this->removeThread();
		}
	}
	
	/**
	 * Deletes the selected thread.
	 */
	public function delete() {
		if ($this->thread == null) {
			throw new IllegalLinkException();
		}
		
		// check permission
		WCF::getUser()->checkPermission('mod.board.canDeleteThreadCompletely');
		
		$this->thread->delete();
		if (!$this->thread->isDeleted || !false) {
			$this->removeThread();
		}
	}
	
	/**
	 * Moves a thread.
	 */
	public function move() {
		ThreadEditor::moveAll($this->threadID, $this->boardID);
		
		// refresh counts
		BoardEditor::refreshAll($this->thread->boardID.','.$this->board->boardID);
		
		// set last post
		$this->board->setLastPosts();
		$oldBoard = new BoardEditor($this->thread->boardID);
		$oldBoard->setLastPosts();
		
		self::resetCache();
	}
	
	/**
	 * Removes a thread.
	 */
	public function removeThread() {
		self::resetCache();
		
		// refresh board last post
		$this->board->refresh();
		if ($this->thread->lastPostTime >= $this->board->getLastPostTime($this->thread->languageID)) {
			$this->board->setLastPosts();
		}
	}
	
	/**
	 * Resets the relavant cache resources.
	 */
	public static function resetCache() {
		// reset stat cache
		WCF::getCache()->clearResource('stat');
		// reset board data cache
		WCF::getCache()->clearResource('boardData', true);
	}
}
?>