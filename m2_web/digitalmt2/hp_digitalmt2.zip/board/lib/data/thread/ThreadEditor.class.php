<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
require_once(WBB_DIR.'lib/data/thread/Thread.class.php');

/**
 * ThreadEditor provides functions to create and edit the data of a thread.
 * 
 * @package	com.woltlab.wbb.data.thread
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class ThreadEditor extends Thread {
	/**
	 * Adds a new post to this thread.
	 *
	 * @param	Post		$post		the new post
	 * @param	integer		$closedThread	true (1), if thread ought to be closed
	 */
	public function addPost($post, $closeThread = 0) {
		$this->data['lastPoster'] = $post->username;
		$this->data['lastPostTime'] = $post->time;
		$this->data['lastPosterID'] = $post->userID;
		$this->data['replies']++;
		$this->data['attachments'] += $post->attachments;
		$this->data['polls'] += $post->pollID ? 1 : 0;
		
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	".(($closeThread) ? ("isClosed = 1,") : (""))."
				replies = replies + 1,
				attachments = attachments + ".$post->attachments.",
				polls = polls + ".($post->pollID ? 1 : 0).",
				lastPostTime = ".$this->lastPostTime.",
				lastPosterID = ".$this->lastPosterID.",
				lastPoster = '".escapeString($this->lastPoster)."'
			WHERE 	threadID = ".$this->threadID;
		WCF::getDB()->sendQuery($sql);
	}
	
	/**
	 * Returns true, if this thread contains posts.
	 * 
	 * @return	boolean		true, if this thread contains posts
	 */
	public function hasPosts() {
		$sql = "SELECT 	COUNT(*) AS count
			FROM 	wbb".WBB_N."_post
			WHERE 	threadID = ".$this->threadID;
		$result = WCF::getDB()->getFirstRow($sql);
		return $result['count'];
	}
	
	/**
	 * Sets the last post of this thread.
	 * 
	 * @param	Post	$post
	 */
	public function setLastPost($post = null) {
		self::__setLastPost($this->threadID, $post);
	}
	
	/**
	 * Moves this thread into the recycle bin.
	 */
	public function trash($trashPosts = true) {
		self::trashAll($this->threadID, $trashPosts);
	}
	
	/**
	 * Deletes this thread completely.
	 */
	public function delete($deletePosts = true, $updateUserStats = true) {
		self::deleteAllCompletely($this->threadID, $deletePosts, $updateUserStats);
	}
	
	/**
	 * Returns the post ids of this thread.
	 */
	public function getPostIDs() {
		return self::getAllPostIDs($this->threadID);
	}
	
	/**
	 * Refreshes the last post, replies, amount of attachments and amount of polls of this thread.
	 */
	public function refresh($refreshLastPost = true) {
		self::refreshAll($this->threadID, $refreshLastPost);
	}
	
	/**
	 * Checks whether this thread is empty, thrashed or hidden. 
	 */
	public function checkVisibility() {
		self::checkVisibilityAll($this->threadID);
	}
	
	/**
	 * Creates a new thread with the given data in the database.
	 * Returns a ThreadEditor object of the new thread.
	 * 
	 * @param	integer				$boardID							
	 * @param	string				$subject		subject of the new thread
	 * @param	string				$text			text of the first post in the new thread
	 * @param	integer				$authorID		user id of the author of the new thread
	 * @param	string				$author			username of the author of the new thread
	 * @param	integer				$sticky			true (1), if it is a sticky thread
	 * @param	integer				$isClosed		true (1), if it is a closed thread					
	 * @param	array				$options		options of the new thread
	 * @param	integer				$subscription		type of notifation on the new thread for the active user					
	 * @param	AttachmentsEditor		$attachmentsEditor
	 * @param	PollEditor			$pollEditor
	 * 
	 * @return	ThreadEditor						the new thread		
	 */
	public static function create($boardID, $languageID, $prefix, $subject, $text, $userID, $username, $sticky = 0, $announcement = 0, $closed = 0, $options = array(), $subscription = 0, $attachments = null, $poll = null, $disabled = 0) {
		$attachmentsAmount = $attachments != null ? count($attachments->getAttachments()) : 0;
		$polls = ($poll != null && $poll->pollID) ? 1 : 0;
		
		// insert thread
		$threadID = self::insert($subject, $boardID, array(
			'languageID' => $languageID,
			'userID' => $userID,
			'username' => $username,
			'prefix' => $prefix,
			'time' => TIME_NOW,
			'lastPostTime' => TIME_NOW,
			'lastPosterID' => $userID,
			'lastPoster' => $username,
			'attachments' => $attachmentsAmount,
			'polls' => $polls,
			'isSticky' => $sticky,
			'isAnnouncement' => $announcement,
			'isClosed' => $closed,
			'isDisabled' => $disabled,
			'everEnabled' => ($disabled ? 0 : 1)
		));
		
		// create post
		$post = PostEditor::create($threadID, $subject, $text, $userID, $username, $options, $attachments, $poll, null, $disabled, true);

		// update first post id
		$sql = "UPDATE	wbb".WBB_N."_thread
			SET	firstPostID = ".$post->postID."
			WHERE	threadID = ".$threadID;
		WCF::getDB()->sendQuery($sql);
		
		// get thread object
		$thread = new ThreadEditor($threadID);
		
		return $thread;
	}
	
	/**
	 * Creates the thread row in database table.
	 *
	 * @param 	string 		$topic
	 * @param	integer		$boardID
	 * @param 	array		$additionalFields
	 * @return	integer		new thread id
	 */
	public static function insert($topic, $boardID, $additionalFields = array()) { 
		$keys = $values = '';
		foreach ($additionalFields as $key => $value) {
			$keys .= ','.$key;
			$values .= ",'".escapeString($value)."'";
		}
		
		$sql = "INSERT INTO	wbb".WBB_N."_thread
					(boardID, topic
					".$keys.")
			VALUES		(".$boardID.", '".escapeString($topic)."'
					".$values.")";
		WCF::getDB()->sendQuery($sql);
		return WCF::getDB()->getInsertID();
	}
	
	/**
	 * Deletes the threads with the given thread ids.
	 */
	public static function deleteAll($threadIDs, $deletePosts = true) {
		if (empty($threadIDs)) return;
		
		$trashIDs = '';
		$deleteIDs = '';
		if (false) {
			// recylce bin enabled
			// first of all we check which threads are already in recylce bin
			$sql = "SELECT 	threadID, isDeleted
				FROM 	wbb".WBB_N."_thread
				WHERE 	threadID IN (".$threadIDs.")";
			$result = WCF::getDB()->sendQuery($sql);
			while ($row = WCF::getDB()->fetchArray($result)) {
				if ($row['isDeleted']) {
					// thread in recylce bin
					// delete completely
					if (!empty($deleteIDs)) $deleteIDs .= ',';
					$deleteIDs .= $row['threadID'];
				}
				else {
					// move thread to recylce bin
					if (!empty($trashIDs)) $trashIDs .= ',';
					$trashIDs .= $row['threadID'];
				}
			}
		}
		else {
			// no recylce bin
			// delete all threads completely
			$deleteIDs = $threadIDs;
		}
		
		self::trashAll($trashIDs, $deletePosts);
		self::deleteAllCompletely($deleteIDs, $deletePosts);
	}
	
	/**
	 * Moves the threads with the given thread ids into the recycle bin.
	 */
	public static function trashAll($threadIDs, $trashPosts = true) {
		if (empty($threadIDs)) return;
		
		// trash thread
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	isDeleted = 1,
				deleteTime = ".TIME_NOW.",
				deletedBy = '".escapeString(WCF::getUser()->username)."',
				deletedByID = ".WCF::getUser()->userID.",
				isDisabled = 0
			WHERE 	threadID IN (".$threadIDs.")";
		WCF::getDB()->sendQuery($sql);
		
		// trash post	
		if ($trashPosts) {
			PostEditor::trashAll(self::getAllPostIDs($threadIDs));
		}
	}
	
	/**
	 * Deletes the threads with the given thread ids completely.
	 */
	public static function deleteAllCompletely($threadIDs, $deletePosts = true, $updateUserStats = true) {
		if (empty($threadIDs)) return;
		
		// update user posts & activity points
		if ($updateUserStats) {
			self::updateUserStats($threadIDs, 'delete');
		}
		
		// delete posts
		if ($deletePosts) {
			PostEditor::deleteAllCompletely(self::getAllPostIDs($threadIDs), true, true, $updateUserStats);
		}
		
		// delete threads
		self::deleteData($threadIDs);
	}
	
	/**
	 * Deletes the sql data of the threads with the given thread ids.
	 */
	protected static function deleteData($threadIDs) {
		// delete thread
		$sql = "DELETE FROM	wbb".WBB_N."_thread
			WHERE 		threadID IN (".$threadIDs.")
					OR movedThreadID IN (".$threadIDs.")";
		WCF::getDB()->sendQuery($sql);
		
		// delete ratingd
		$sql = "DELETE FROM	wbb".WBB_N."_thread_rating
			WHERE 		threadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		// delete subscriptions
		$sql = "DELETE FROM 	wbb".WBB_N."_thread_subscription
			WHERE 		threadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		// delete thread visits
		$sql = "DELETE FROM	wbb".WBB_N."_thread_visit
			WHERE 		threadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		// delete announcements
		$sql = "DELETE FROM	wbb".WBB_N."_thread_announcement
			WHERE 		threadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		// delete similar threads
		$sql = "DELETE FROM	wbb".WBB_N."_thread_similar
			WHERE 		threadID IN (".$threadIDs.")
					OR similarThreadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Returns the ids of the posts with the given thread ids.
	 */
	public static function getAllPostIDs($threadIDs) {
		if (empty($threadIDs)) return;
		
		$postIDs = '';
		$sql = "SELECT	postID
			FROM 	wbb".WBB_N."_post
			WHERE 	threadID IN (".$threadIDs.")";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (!empty($postIDs)) $postIDs .= ',';
			$postIDs .= $row['postID'];
		}
		
		return $postIDs;
	}
	
	/**
	 * Returns the boards of the threads with the given thread ids.
	 * 
	 * @param	string		$threadIDs
	 * @return	array
	 */
	public static function getBoards($threadIDs) {
		if (empty($threadIDs)) return array(array(), '', 'boards' => array(), 'boardIDs' => '');
		
		$boards = array();
		$boardIDs = '';
		$sql = "SELECT 	DISTINCT boardID
			FROM 	wbb".WBB_N."_thread
			WHERE 	threadID IN (".$threadIDs.")";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (!empty($boardIDs)) $boardIDs .= ',';
			$boardIDs .= $row['boardID'];
			$boards[] = new BoardEditor($row['boardID']);
		}
		
		return array($boards, $boardIDs, 'boards' => $boards, 'boardIDs' => $boardIDs);
	}
	
	/**
	 * Checks whether the threads with the given thread ids are empty, thrashed or hidden. 
	 */
	public static function checkVisibilityAll($threadIDs) {
		if (empty($threadIDs)) return;
		
		$emptyThreads = '';
		$trashedThreads = '';
		$hiddenThreads = '';
		$enabledThreads = '';
		$restoresThreads = '';
		$sql = "SELECT		COUNT(post.postID) AS posts,
					SUM(post.isDeleted) AS deletedPosts,
					SUM(post.isDisabled) AS hiddenPosts,
					thread.threadID, thread.isDeleted, thread.isDisabled
			FROM 		wbb".WBB_N."_thread thread
			LEFT JOIN 	wbb".WBB_N."_post post
			ON 		(post.threadID = thread.threadID)
			WHERE 		thread.threadID IN (".$threadIDs.")
			GROUP BY 	thread.threadID";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$row['deletedPosts'] = intval($row['deletedPosts']);
			$row['hiddenPosts'] = intval($row['hiddenPosts']);
			
			// thread has no posts
			// delete thread
			if ($row['posts'] == 0) {
				if (!empty($emptyThreads)) $emptyThreads .= ',';
				$emptyThreads .= $row['threadID'];
			}
			
			// all posts of this thread are into the recylce bin
			// move thread also into the recylce bin  
			else if ($row['posts'] == $row['deletedPosts']) {
				if (!empty($trashedThreads)) $trashedThreads .= ',';
				$trashedThreads .= $row['threadID'];
			}
			
			// all posts of this thread are hidden
			// hide thread also
			else if ($row['posts'] == $row['hiddenPosts'] || $row['posts'] == $row['hiddenPosts'] + $row['deletedPosts']) {
				if (!empty($hiddenThreads)) $hiddenThreads .= ',';
				$hiddenThreads .= $row['threadID'];
			}
			
			// thread is deleted, but no posts are deleted
			// restore thread
			else if (intval($row['deletedPosts']) == 0 && $row['isDeleted'] == 1) {
				if (!empty($restoresThreads)) $restoresThreads .= ',';
				$restoresThreads .= $row['threadID'];
			}
			
			// thread is hidden, but no posts are hidden
			// enable thread
			else if (intval($row['hiddenPosts']) == 0 && $row['isDisabled'] == 1) {
				if (!empty($enabledThreads)) $enabledThreads .= ',';
				$enabledThreads .= $row['threadID'];
			}
		}
		
		self::deleteAllCompletely($emptyThreads, false, false);
		self::trashAll($trashedThreads, false);
	}
	
	/**
	 * Refreshes the last post, replies, amount of attachments and amount of polls of this thread.
	 */
	public static function refreshAll($threadIDs, $refreshLastPost = true, $refreshFirstPostID = true) {
		if (empty($threadIDs)) return;
		
		$sql = "UPDATE 	wbb".WBB_N."_thread thread
			SET	replies = IF(thread.isDeleted = 0 AND thread.isDisabled = 0,
					(
						SELECT 	COUNT(*)
						FROM 	wbb".WBB_N."_post
						WHERE 	threadID = thread.threadID
							AND isDeleted = 0
							AND isDisabled = 0
					) - 1, replies),
				attachments = IFNULL((
					SELECT 	SUM(attachments)
					FROM 	wbb".WBB_N."_post
					WHERE 	threadID = thread.threadID
						AND isDeleted = 0
						AND isDisabled = 0
				), 0),
				polls = (
					SELECT 	COUNT(*)
					FROM 	wbb".WBB_N."_post
					WHERE 	threadID = thread.threadID
						AND isDeleted = 0
						AND isDisabled = 0
						AND pollID <> 0
				)
			WHERE 	threadID IN (".$threadIDs.")";
		WCF::getDB()->sendQuery($sql);
		
		if ($refreshLastPost) {
			self::setLastPostAll($threadIDs);
		}
		
		if ($refreshFirstPostID) {
			self::refreshFirstPostIDAll($threadIDs);
		}
	}
	
	/**
	 * Sets the last post of the threads with the given thread ids.
	 */
	public static function setLastPostAll($threadIDs) {
		if (empty($threadIDs)) return;
		
		$threads = explode(',', $threadIDs);
		foreach ($threads as $threadID) {
			self::__setLastPost($threadID);
		}
	}
	
	/**
	 * Sets the last post of the thread with the given thread id.
	 */
	protected static function __setLastPost($threadID, $post = null) {
		if ($post != null) {
			$result = array('time' => $post->time, 'userID' => $post->userID, 'username' => $post->username);
		}
		else {
			$sql = "SELECT		time, userID, username
				FROM 		wbb".WBB_N."_post
				WHERE 		threadID = ".$threadID."
						AND isDeleted = 0
						AND isDisabled = 0
				ORDER BY 	time DESC";
			$result = WCF::getDB()->getFirstRow($sql);
		}
		
		if ($result['time']) {
			$sql = "UPDATE 	wbb".WBB_N."_thread
				SET	lastPostTime = ".intval($result['time']).",
					lastPosterID = ".intval($result['userID']).",
					lastPoster = '".escapeString($result['username'])."'
				WHERE 	threadID = ".$threadID;
		}
		else {
			$sql = "UPDATE 	wbb".WBB_N."_thread
				SET	lastPostTime = time,
					lastPosterID = userID,
					lastPoster = username
				WHERE 	threadID = ".$threadID;
		}
		WCF::getDB()->sendQuery($sql);
	}
	
	/**
	 * Updates thread data.
	 */
	public function update($threadData) {
		$updateSql = '';
		foreach ($threadData as $key => $value) {
			if (!empty($updateSql)) $updateSql .= ',';
			$updateSql .= $key."='".escapeString($value)."'";
		}
		
		if (!empty($updateSql)) {
			$sql = "UPDATE 	wbb".WBB_N."_thread
				SET	".$updateSql."
				WHERE	threadID = ".$this->threadID;
			WCF::getDB()->sendQuery($sql);
		}
	}
	
	/**
	 * Refreshes the first post ids of given threads.
	 * 
	 * @param	string		$threadIDs
	 */
	public static function refreshFirstPostIDAll($threadIDs) {
		$threadIDsArray = explode(',', $threadIDs);
		foreach ($threadIDsArray as $threadID) {
			// get post
			$sql = "SELECT 		postID, threadID, time, userID, username
				FROM 		wbb".WBB_N."_post post
				WHERE 		threadID = ".$threadID."
				ORDER BY 	time ASC";
			$row = WCF::getDB()->getFirstRow($sql);
			if (!empty($row['postID'])) {
				$sql = "UPDATE	wbb".WBB_N."_thread
					SET	firstPostID = ".$row['postID'].",
						time = ".$row['time'].",
						userID = ".$row['userID'].",
						username = '".escapeString($row['username'])."'
					WHERE	threadID = ".$threadID;
				WCF::getDB()->sendQuery($sql);
			}
		}
	}
	
	/**
	 * Updates the user stats (user posts, activity points & user rank).
	 * 
	 * @param	string		$threadIDs		changed threads
	 * @param 	string		$mode			(enable|copy|move|delete)
	 * @param 	integer		$destinationBoardID
	 */
	public static function updateUserStats($threadIDs, $mode, $destinationBoardID = 0) {
		if (empty($threadIDs)) return;
		
		// get destination board
		$destinationBoard = null;
		if ($destinationBoardID) $destinationBoard = Board::getBoard($destinationBoardID);
		if ($mode == 'copy' && !$destinationBoard->countUserPosts) return;
		
		// update user posts, activity points
		$userPosts = array();
		$userActivityPoints = array();
		$sql = "SELECT	boardID, userID
			FROM	wbb".WBB_N."_thread
			WHERE	threadID IN (".$threadIDs.")
				".($mode != 'enable' ? "AND everEnabled = 1" : '')."
				AND userID <> 0";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$board = Board::getBoard($row['boardID']);
			
			switch ($mode) {
				case 'enable':
					if ($board->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]++;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ACTIVITY_POINTS_PER_THREAD;
					}
					break;
				case 'copy':
					if ($destinationBoard->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]++;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ACTIVITY_POINTS_PER_THREAD;
					}
					break;
				case 'move':
					if ($board->countUserPosts != $destinationBoard->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']] += ($board->countUserPosts ? -1 : 1);
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ($board->countUserPosts ? ACTIVITY_POINTS_PER_THREAD * -1 : ACTIVITY_POINTS_PER_THREAD);
					}
					break;
				case 'delete':
					if ($board->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]--;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] -= ACTIVITY_POINTS_PER_THREAD;
					}
					break;
			}
		}
		
		// save posts
		if (count($userPosts)) {
			require_once(WBB_DIR.'lib/data/user/WBBUser.class.php');
			foreach ($userPosts as $userID => $posts) {
				WBBUser::updateUserPosts($userID, $posts);
			}
		}
		
		// save activity points
		if (count($userActivityPoints)) {
			require_once(WCF_DIR.'lib/data/user/rank/UserRank.class.php');
			foreach ($userActivityPoints as $userID => $points) {
				UserRank::updateActivityPoints($points, $userID);
			}
		}
	}
	
	/**
	 * Closes this thread.
	 */
	public function close() {
		self::closeAll($this->threadID);
	}
	
	/**
	 * Closes the threads with given ids.
	 * 
	 * @param	string		$threadIDs
	 */
	public static function closeAll($threadIDs) {
		if (empty($threadIDs)) return;
		
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	isClosed = 1
			WHERE 	threadID IN (".$threadIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Opens this thread.
	 */
	public function open() {
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	isClosed = 0
			WHERE 	threadID = ".$this->threadID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Moves all threads with the given ids into the board with the given board id.
	 */
	public static function moveAll($threadIDs, $newBoardID) {
		if (empty($threadIDs)) return;
		
		// update user posts & activity points (threads)
		self::updateUserStats($threadIDs, 'move', $newBoardID);
		
		// get post ids
		$postIDs = '';
		$sql = "SELECT	postID
			FROM	wbb".WBB_N."_post
			WHERE	threadID IN (".$threadIDs.")";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (!empty($postIDs)) $postIDs .= ',';
			$postIDs .= $row['postID'];
		}
		
		// update user posts & activity points (posts)
		PostEditor::updateUserStats($postIDs, 'move', $newBoardID);
		
		// move threads
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	boardID = ".$newBoardID."
			WHERE 	threadID IN (".$threadIDs.")
				AND boardID <> ".$newBoardID;
		WCF::getDB()->sendQuery($sql);
	}
}
?>