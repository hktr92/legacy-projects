<?php
// wbb imports
require_once(WBB_DIR.'lib/data/thread/Thread.class.php');

/**
 * Represents a viewable thread in the forum.
 *
 * @package	com.woltlab.wbb.data.thread
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class ViewableThread extends Thread {
	/**
	 * Handles the given resultset.
	 *
	 * @param 	array 		$row		resultset with thread data form database
	 */
	protected function handleData($data) {
		parent::handleData($data);
		
		// handle moved threads
		$this->data['realThreadID'] = $this->threadID;
		if ($this->movedThreadID != 0) $this->data['threadID'] = $this->movedThreadID;
		
		// get last visit time
		if (!$this->lastVisitTime && WCF::getUser()->userID == 0) {
			// user is guest; get thread visit from session
			$this->data['lastVisitTime'] = WCF::getUser()->getThreadVisitTime($this->threadID);
		}
		
		if ($this->lastVisitTime < WCF::getUser()->getBoardVisitTime($this->boardID)) {
			$this->data['lastVisitTime'] = WCF::getUser()->getBoardVisitTime($this->boardID);
		}
	}
	
	/**
	 * Gets the number of pages in this thread.
	 *
	 * @return	integer		number of pages in this thread
	 */
	public function getPages() {
		return intval(ceil(($this->replies + 1) / THREAD_POSTS_PER_PAGE));
	}
	
	/**
	 * Returns true, if this thread is new for the active user.
	 *
	 * @return	boolean		true, if this thread is new for the active user
	 */
	public function isNew() {
		if (!$this->movedThreadID && $this->lastPostTime > $this->lastVisitTime) {
			return true;	
		}
		
		return false;
	}
	
	/**
	 * Returns the filename of the thread icon.
	 *
	 * @return	string		filename of the thread icon
	 */
	public function getIconName() {
		// deleted
		if ($this->isDeleted) return 'threadTrash';
		
		$icon = 'thread';
		
		// new
		if ($this->isNew()) $icon .= 'New';
		
		// moved
		if ($this->movedThreadID) {
			$icon .= 'Moved';
			
			// closed
			if ($this->isClosed) $icon .= 'Closed';
			
			return $icon;
		}
		
		// important
		//if ($this->isAnnouncement == 1) $icon .= 'Announcement';
		//else if ($this->isSticky == 1) $icon .= 'Important';
		
		// closed
		if ($this->isClosed) $icon .= 'Closed';
		
		return $icon;
	}
}
?>