<?php
require_once(WBB_DIR.'lib/data/thread/ViewableThread.class.php');

/**
 * ThreadList is a default implementation for displaying a list of threads. 
 * 
 * @package	com.woltlab.wbb.data.thread
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class ThreadList {
	// parameters
	public $limit = 20, $offset = 0;
	
	// data
	public $threads = array();
	public $threadIDs = '';
	
	// sql plugin options
	public $sqlConditions = '';
	public $sqlOrderBy = 'thread.lastPostTime DESC';
	public $sqlSelects = '';
	public $sqlJoins = '';
	
	/**
	 * Creates a new ThreadList object.
	 */
	public function __construct() {
		// default sql conditions
		$this->initDefaultSQL();
	}
	
	/**
	 * Fills the sql parameters with default values.
	 */
	protected function initDefaultSQL() {
		if (WCF::getUser()->userID != 0) {
			// last visit time
			$this->sqlSelects .= 'thread_visit.lastVisitTime,';
			$this->sqlJoins .= "	LEFT JOIN 	wbb".WBB_N."_thread_visit thread_visit 
						ON 		(thread_visit.threadID = thread.threadID
								AND thread_visit.userID = ".WCF::getUser()->userID.")";
		}
	}
	
	/**
	 * Counts threads.
	 * 
	 * @return	integer
	 */
	public function countThreads() {
		$sql = "SELECT	COUNT(*) AS count
			FROM	wbb".WBB_N."_thread thread
			".(!empty($this->sqlConditions) ? "WHERE ".$this->sqlConditions : "");
		$row = WCF::getDB()->getFirstRow($sql);
		return $row['count'];
	}
	
	/**
	 * Gets thread ids.
	 */
	protected function readThreadIDs() {
		$sql = "SELECT		thread.threadID
			FROM		wbb".WBB_N."_thread thread
			".(!empty($this->sqlConditions) ? "WHERE ".$this->sqlConditions : "")."
			ORDER BY	".$this->sqlOrderBy;
		$result = WCF::getDB()->sendQuery($sql, $this->limit, $this->offset);
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (!empty($this->threadIDs)) $this->threadIDs .= ',';
			$this->threadIDs .= $row['threadID'];
		}
	}
	
	/**
	 * Reads a list of threads.
	 */
	public function readThreads() {
		// get post ids
		$this->readThreadIDs();
		if (empty($this->threadIDs)) return false;

		// get threads
		$sql = $this->buildQuery();
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$this->threads[] = new ViewableThread(null, $row);
		}
	}
	
	/**
	 * Builds the main sql query for selecting threads.
	 * 
	 * @return	string
	 */
	protected function buildQuery() {
		return "SELECT		".$this->sqlSelects."
					thread.*
			FROM 		wbb".WBB_N."_thread thread
			".$this->sqlJoins."
			WHERE		thread.threadID IN (".$this->threadIDs.")
			ORDER BY	".$this->sqlOrderBy;
	}
}
?>