<?php
require_once(WBB_DIR.'lib/data/thread/Thread.class.php');
require_once(WBB_DIR.'lib/data/board/Board.class.php');
require_once(WBB_DIR.'lib/data/post/PostList.class.php');

/**
 * Shows a list of dependent posts.
 *
 * @package	com.woltlab.wbb.data.post
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class DependentPostList extends PostList {
	public $board;
	public $sqlConditionVisible = '';
	
	/**
	 * Creates a new DependentPostList object.
	 * 
	 * @param	Thread		$thread
	 * @param	Board		$board
	 */
	public function __construct(Thread $thread, Board $board) {
		$this->thread = $thread;
		$this->board = $board;
		$this->canDownloadAttachment = $this->board->getPermission('canDownloadAttachment');
		
		parent::__construct();
	}
	
	/**
	 * @see PostList::initDefaultSQL();
	 */
	protected function initDefaultSQL() {
		parent::initDefaultSQL();

		// default sql conditions
		$this->sqlConditions = "threadID = ".$this->thread->threadID;
		$this->sqlConditions .= $this->sqlConditionVisible;
	}
}
?>