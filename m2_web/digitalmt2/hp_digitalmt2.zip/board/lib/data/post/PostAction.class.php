<?php
// wbb imports
require_once(WBB_DIR.'lib/data/post/PostEditor.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadAction.class.php');

/**
 * Executes moderation actions on posts.
 * 
 * @package	com.woltlab.wbb.data.post
 * @author	Michael Schaefer
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class PostAction {
	protected $topic = '';
	protected $url = '';
	protected $postIDs = null;
	protected $post = null;
	protected $thread = null;
	protected $board = null;
	protected $quotes = null;
	
	/**
	 * Creates a new PostAction object.
	 * 
	 * @param	BoardEditor	$board
	 * @param	ThreadEditor	$thread
	 * @param	PostEditor	$post
	 */
	public function __construct($board = null, $thread = null, $post = null, $topic = '', $forwardURL = '') {
		$this->board = $board;
		$this->thread = $thread;
		$this->post = $post;
		$this->topic = $topic;
		$this->url = $forwardURL;
		if (empty($this->url) && $this->thread) $this->url = 'index.php?page=Thread&threadID='.$this->thread->threadID.SID_ARG_2ND_NOT_ENCODED;
	}
	
	/**
	 * Trashes the selected post.
	 */
	public function trash($ignorePermission = false) {
		if (!false || (!$ignorePermission && !WCF::getUser()->getPermission('mod.board.canDeletePost'))) {
			return;
		}
		
		if ($this->post != null && !$this->post->isDeleted) {
			$this->post->trash();
			$this->thread->checkVisibility();
			$this->removePost();
		}
	}
	
	/**
	 * Deletes the selected post.
	 */
	public function delete($canDeletePost = false) {
		if ($this->post == null) {
			throw new IllegalLinkException();
		}
		
		// check permission
		if (!$canDeletePost) {
			WCF::getUser()->checkPermission('mod.board.canDeletePostCompletely');
		}
		
		// remove user stats
		ThreadEditor::updateUserStats($this->thread->threadID, 'delete');
		PostEditor::updateUserStats(ThreadEditor::getAllPostIDs($this->thread->threadID), 'delete');
		
		$this->post->delete(false);
	
		if ($this->thread->hasPosts()) {
			// delete only post
			$this->thread->checkVisibility();
			if (!$this->post->isDeleted || !false) {
				$this->removePost();
			}
			else {
				ThreadEditor::refreshFirstPostIDAll($this->thread->threadID);
			}
			
			// re-add user stats
			ThreadEditor::updateUserStats($this->thread->threadID, 'enable');
			PostEditor::updateUserStats(ThreadEditor::getAllPostIDs($this->thread->threadID), 'enable');
		
			// forward
			HeaderUtil::redirect($this->url);
			exit;
		}
		else {
			// delete complete thread
			$this->thread->delete(false, false);
			if (!$this->post->isDeleted || !false) {
				$this->board->refresh();
				if ($this->post->time >= $this->board->getLastPostTime($this->thread->languageID)) {
					$this->board->setLastPosts();
				}
				
				// reset cache
				ThreadAction::resetCache();
			}
			
			HeaderUtil::redirect('index.php?page=Board&boardID='.$this->board->boardID.SID_ARG_2ND_NOT_ENCODED);
			exit;
		}
	}
	
	/**
	 * Removes a post.
	 */
	public function removePost() {
		// reset cache
		ThreadAction::resetCache();
		
		// refresh thread
		$this->thread->refresh(false);
		if ($this->post->time >= $this->thread->lastPostTime) {
			$this->thread->setLastPost();
		}
		
		// refresh board
		$this->board->refresh();
		if ($this->post->time >= $this->board->getLastPostTime($this->thread->languageID)) {
			$this->board->setLastPosts();
		}
	}
}
?>