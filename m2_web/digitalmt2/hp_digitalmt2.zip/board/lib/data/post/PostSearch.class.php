<?php
// wcf imports
require_once(WCF_DIR.'lib/data/message/search/AbstractSearchableMessageType.class.php');

/**
 * An implementation of SearchableMessageType for searching in forum posts.
 * 
 * @package	com.woltlab.wbb.data.post
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class PostSearch extends AbstractSearchableMessageType {
	protected $messageCache = array();
	protected $threadTableJoin = false;
	
	/**
	 * Caches the data of the messages with the given ids.
	 */
	public function cacheMessageData($messageIDs, $additionalData = null) {
		$sql = "SELECT		post.*,
					thread.topic, thread.prefix,
					board.boardID, board.title
			FROM		wbb".WBB_N."_post post
			LEFT JOIN 	wbb".WBB_N."_thread thread
			ON 		(thread.threadID = post.threadID)
			LEFT JOIN 	wbb".WBB_N."_board board
			ON 		(board.boardID = thread.boardID)
			WHERE		post.postID IN (".$messageIDs.")";
		$result = WCF::getDB()->sendQuery($sql);
		require_once(WBB_DIR.'lib/data/post/PostSearchResult.class.php');
		while ($row = WCF::getDB()->fetchArray($result)) {
			$this->messageCache[$row['postID']] = array('type' => 'post', 'message' => new PostSearchResult(null, $row));
		}
	}
	
	/**
	 * @see SearchableMessageType::getMessageData()
	 */
	public function getMessageData($messageID, $additionalData = null) {
		if (isset($this->messageCache[$messageID])) return $this->messageCache[$messageID];
		return null;
	}
	
	private function includeSubBoards($boardID) {
		if (isset($this->boardStructure[$boardID])) {
			foreach ($this->boardStructure[$boardID] as $childBoardID) {
				if (!isset($this->selectedBoards[$childBoardID])) {
					$this->selectedBoards[$childBoardID] = $this->boards[$childBoardID];
					
					// include children
					$this->includeSubBoards($childBoardID);
				}
			}
		}
	}
	
	/**
	 * Returns the conditions for a search in the table of this search type.
	 */
	public function getConditions($form = null) {
		// get all boards from cache
		require_once(WBB_DIR.'lib/data/board/Board.class.php');
		$boards = WCF::getCache()->get('board', 'boards');
		$boardStructure = WCF::getCache()->get('board', 'boardStructure');
		$selectedBoards = $boards;
		
		// check permission of the active user
		foreach ($selectedBoards as $board) {
			if (!$board->getPermission() || !$board->getPermission('canEnterBoard') || !$board->getPermission('canReadThread')) {
				unset($selectedBoards[$board->boardID]);
			}
		}
		
		if (count($selectedBoards) == 0) {
			throw new PermissionDeniedException();
		}
		
		// build board id list
		$selectedBoardIDs = '';
		if (count($selectedBoards) != count($boards)) {
			foreach ($selectedBoards as $board) {
				if (!empty($selectedBoardIDs)) $selectedBoardIDs .= ',';
				$selectedBoardIDs .= $board->boardID;
			}
		}
		
		// return sql condition
		$conditions = '';
		if (!empty($selectedBoardIDs)) {
			$this->threadTableJoin = true;
			$conditions = '(thread.threadID = messageTable.threadID AND thread.boardID IN ('.$selectedBoardIDs.'))';
		}
		
		return $conditions;
	}
	
	/**
	 * @see SearchableMessageType::getJoins()
	 */
	public function getJoins() {
		return ($this->threadTableJoin ? ", wbb".WBB_N."_thread thread" : '');
	}
	
	/**
	 * Returns the database table name for this search type.
	 */
	public function getTableName() {
		return 'wbb'.WBB_N.'_post';
	}
	
	/**
	 * Returns the message id field name for this search type.
	 */
	public function getIDFieldName() {
		return 'postID';
	}
	
	/**
	 * @see SearchableMessageType::getResultTemplateName()
	 */
	public function getResultTemplateName() {
		return 'searchResultPost';
	}
}
?>