<?php
// wcf imports
require_once(WCF_DIR.'lib/data/message/Message.class.php');

/**
 * Represents a post in the forum.
 *
 * @package	com.woltlab.wbb.data.post
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class Post extends Message {
	/**
	 * Creates a new post object.
	 *
	 * If id is set, the function reads the post data from database.
	 * Otherwise it uses the given resultset.
	 *
	 * @param 	integer 	$postID		id of a post
	 * @param 	array 		$row		resultset with post data form database
	 */
	public function __construct($postID, $row = null) {
		if ($postID !== null) {
			$sql = "SELECT	*
				FROM 	wbb".WBB_N."_post
				WHERE 	postID = ".$postID;
			$row = WCF::getDB()->getFirstRow($sql);
		}
		parent::__construct($row);
		$this->messageID = $row['postID'];
	}
	
	/**
	 * Returns true, if the active user can edit or delete this post.
	 * 
	 * @param	Board		$board
	 * @param	Thread		$thread
	 * @return	boolean
	 */
	public function canEditPost($board, $thread) {
		$isModerator = WCF::getUser()->getPermission('mod.board.canEditPost') || WCF::getUser()->getPermission('mod.board.canDeletePost');
		$isAuthor = $this->userID && $this->userID == WCF::getUser()->userID;
		
		$canEditPost = WCF::getUser()->getPermission('mod.board.canEditPost') || $isAuthor && $board->getPermission('canEditOwnPost');
		$canDeletePost = WCF::getUser()->getPermission('mod.board.canDeletePost') || $isAuthor && $board->getPermission('canDeleteOwnPost');

		if ((!$canEditPost && !$canDeletePost) || (!$isModerator && ($board->isClosed || $thread->isClosed || $this->isClosed))) {
			return false;
		}
		
		return true;
	}
}
?>