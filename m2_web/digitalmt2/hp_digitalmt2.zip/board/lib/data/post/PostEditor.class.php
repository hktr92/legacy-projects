<?php
// wbb imports
require_once(WBB_DIR.'lib/data/post/Post.class.php');

/**
 * PostEditor provides functions to create and edit the data of a post.
 * 
 * @package	com.woltlab.wbb.data.post
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class PostEditor extends Post {
	/**
	 * Updates the data of this post.
	 * 
	 * @param	string				$subject		new subject of this post
	 * @param	string				$message		new text of this post
	 * @param	array				$options		new options of this post
	 * @param	AttachmentsEditor		$attachments		
	 * @param	PollEditor			$poll
	 */
	public function update($subject, $message, $options, $attachments = null, $poll = null, $additionalData = array()) {
		$updateSubject = $updateText = '';
		$attachmentsAmount = $attachments != null ? count($attachments->getAttachments($this->postID)) : 0;
		
		// save subject
		if ($subject != $this->subject) {
			$updateSubject = "subject = '".escapeString($subject)."',";
		}
		
		// save message
		$updateText = "message = '".escapeString($message)."',";
		
		// assign attachments
		if ($attachments != null) {
			require_once(WCF_DIR.'lib/data/message/bbcode/AttachmentBBCode.class.php');
			AttachmentBBCode::setAttachments($attachments->getSortedAttachments());
		}
		
		// update post cache
		require_once(WCF_DIR.'lib/data/message/bbcode/MessageParser.class.php');
		$parser = MessageParser::getInstance();
		$parser->setOutputType('text/html');
		$sql = "UPDATE	wbb".WBB_N."_post_cache
			SET	messageCache = '".escapeString($parser->parse($message, $options['enableSmilies'], $options['enableHtml'], $options['enableBBCodes'], false))."'
			WHERE	postID = ".$this->postID;
		WCF::getDB()->registerShutdownUpdate($sql);
		
		$additionalSql = '';
		foreach ($additionalData as $key => $value) {
			$additionalSql .= ','.$key."='".escapeString($value)."'";
		}
		
		// save post in database
		$sql = "UPDATE 	wbb".WBB_N."_post
			SET	$updateSubject
				$updateText
				attachments = ".$attachmentsAmount.",
				".($poll != null ? "pollID = ".intval($poll->pollID)."," : '')."
				enableSmilies = ".$options['enableSmilies'].",
				enableHtml = ".$options['enableHtml'].",
				enableBBCodes = ".$options['enableBBCodes']."
				".$additionalSql."
			WHERE 	postID = ".$this->postID;
		WCF::getDB()->sendQuery($sql);
		
		// update attachments
		if ($attachments != null) {
			$attachments->findEmbeddedAttachments($message);
		}
		// update poll
		if ($poll != null) {
			$poll->updateMessageID($this->postID);
		}
		
		// refresh thread data
		require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');
		ThreadEditor::refreshAll($this->threadID, false);
	}
	
	/**
	 * Sets the subject of this message.
	 * 
	 * @param	string		$subject	new subject for this message
	 */
	public function setSubject($subject) {
		$sql = "UPDATE 	wbb".WBB_N."_post SET
				subject = '".escapeString($subject)."'
			WHERE 	postID = ".$this->postID;
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Moves this post in the recycle bin.
	 */
	public function trash() {
		self::trashAll($this->postID);
	}
	
	/**
	 * Deletes this post completely.
	 * 
	 * Deletes the attachments and the poll of this post and
	 * the sql data in tables post, post_cache and post_report.
	 */
	public function delete($updateUserStats = true) {
		self::deleteAllCompletely($this->postID, $this->attachments > 0, $this->pollID != 0, $updateUserStats);
	}
	
	/**
	 * Creates a new post with the given data in the database.
	 * Returns a PostEditor object of the new post.
	 * 
	 * @param	integer				$threadID							
	 * @param	string				$subject		subject of the new post
	 * @param	string				$text			text of the new post
	 * @param	integer				$userID			user id of the author of the new post
	 * @param	string				$username		username of the author of the new post
	 * @param	array				$options		options of the new post
	 * @param	AttachmentsEditor		$attachmentsEditor
	 * @param	PollEditor			$pollEditor
	 * 
	 * @return	PostEditor						the new post		
	 */
	public static function create($threadID, $subject, $message, $userID, $username, $options, $attachments = null, $poll = null, $ipAddress = null, $disabled = 0, $firstPost = false) {
		if ($ipAddress == null) $ipAddress = WCF::getSession()->ipAddress;
		$hash = StringUtil::getHash(($firstPost ? '' : $threadID) . $subject . $message . $userID . $username);
		$attachmentsAmount = $attachments != null ? count($attachments->getAttachments()) : 0;
		
		// insert post
		$postID = self::insert($subject, $message, $threadID, array(
			'userID' => $userID,
			'username' => $username,
			'time' => TIME_NOW,
			'attachments' => $attachmentsAmount,
			'enableSmilies' => $options['enableSmilies'],
			'enableHtml' => $options['enableHtml'],
			'enableBBCodes' => $options['enableBBCodes'],
			'pollID' => ($poll != null ? intval($poll->pollID) : 0),
			'isDisabled' => $disabled,
			'everEnabled' => ($disabled ? 0 : 1)
		));
		
		// save hash
		$sql = "INSERT INTO	wbb".WBB_N."_post_hash
					(postID, messageHash, time)
			VALUES		(".$postID.", '".$hash."', ".TIME_NOW.")";
		WCF::getDB()->sendQuery($sql);
		
		// get post
		$post = new PostEditor($postID);
		
		// assign attachments
		if ($attachments != null) {
			require_once(WCF_DIR.'lib/data/message/bbcode/AttachmentBBCode.class.php');
			AttachmentBBCode::setAttachments($attachments->getSortedAttachments());
		}
		
		// create post cache
		require_once(WCF_DIR.'lib/data/message/bbcode/MessageParser.class.php');
		$parser = MessageParser::getInstance();
		$parser->setOutputType('text/html');
		$sql = "INSERT INTO 	wbb".WBB_N."_post_cache
					(postID, threadID, messageCache)
			VALUES		(".$postID.",
					".$threadID.",
					'".escapeString($parser->parse($post->message, $post->enableSmilies, $post->enableHtml, $post->enableBBCodes, false))."')";
		WCF::getDB()->sendQuery($sql);
	
		// update attachments & poll
		if ($attachments != null) {
			$attachments->updateContainerID($postID);
			$attachments->findEmbeddedAttachments($message);
		}
		if ($poll != null) {
			$poll->updateMessageID($postID);
		}
		
		return $post;
	}
	
	/**
	 * Creates the post row in database table.
	 *
	 * @param 	string 		$subject
	 * @param 	string		$message
	 * @param	integer		$threadID
	 * @param 	array		$additionalFields
	 * @return	integer		new post id
	 */
	public static function insert($subject, $message, $threadID, $additionalFields = array()){ 
		$keys = $values = '';
		foreach ($additionalFields as $key => $value) {
			$keys .= ','.$key;
			$values .= ",'".escapeString($value)."'";
		}
		
		$sql = "INSERT INTO	wbb".WBB_N."_post
					(threadID, subject, message
					".$keys.")
			VALUES		(".$threadID.", '".escapeString($subject)."', '".escapeString($message)."'
					".$values.")";
		WCF::getDB()->sendQuery($sql);
		return WCF::getDB()->getInsertID();
	}
	
	/**
	 * Checks whether a post with the given data already exists in the database.
	 * 
	 * @param	string		$subject
	 * @param	string		$text
	 * @param	integer		$authorID
	 * @param	string		$author
	 * @param	integer		$threadID
	 * 
	 * @return	boolean		true, if a post with the given data already exists in the database
	 */
	public static function test($subject, $message, $authorID, $author, $threadID = 0) {
		$hash = StringUtil::getHash(($threadID ? $threadID : '') . $subject . $message . $authorID . $author);
		$sql = "SELECT		postID
			FROM 		wbb".WBB_N."_post_hash
			WHERE 		messageHash = '".$hash."'";
		$row = WCF::getDB()->getFirstRow($sql);
		if (!empty($row['postID'])) return $row['postID'];
		return false;
	}
	
	/**
	 * Creates the preview of a post with the given data.
	 * 
	 * @param	string		$subject
	 * @param	string		$text
	 * 
	 * @return	string		the preview of a post 
	 */
	public static function createPreview($subject, $message, $enableSmilies = 1, $enableHtml = 0, $enableBBCodes = 1) {
		$row = array(
			'postID' => 0,
			'subject' => $subject,
			'message' => $message,
			'enableSmilies' => $enableSmilies,
			'enableHtml' => $enableHtml,
			'enableBBCodes' => $enableBBCodes,
			'messagePreview' => true
		);

		require_once(WBB_DIR.'lib/data/post/ViewablePost.class.php');
		$post = new ViewablePost(null, $row);
		return $post->getFormattedMessage();
	}
	
	/**
	 * Deletes the posts with the given post ids.
	 */
	public static function deleteAll($postIDs) {
		if (empty($postIDs)) return;
		
		$trashIDs = '';
		$deleteIDs = '';
		if (false) {
			// recylce bin enabled
			// first of all we check which posts are already in recylce bin
			$sql = "SELECT 	postID, isDeleted
				FROM 	wbb".WBB_N."_post
				WHERE 	postID IN (".$postIDs.")";
			$result = WCF::getDB()->sendQuery($sql);
			while ($row = WCF::getDB()->fetchArray($result)) {
				if ($row['isDeleted']) {
					// post in recylce bin
					// delete completely
					if (!empty($deleteIDs)) $deleteIDs .= ',';
					$deleteIDs .= $row['postID'];
				}
				else {
					// move post to recylce bin
					if (!empty($trashIDs)) $trashIDs .= ',';
					$trashIDs .= $row['postID'];
				}
			}
		}
		else {
			// no recylce bin
			// delete all threads completely
			$deleteIDs = $postIDs;
		}
		
		self::trashAll($trashIDs);
		self::deleteAllCompletely($deleteIDs);
		
		// reset first post id 
		self::resetFirstPostID($postIDs);
	}
	
	/**
	 * Moves the posts with the given post ids into the recycle bin.
	 */
	public static function trashAll($postIDs) {
		if (empty($postIDs)) return;
		
		$sql = "UPDATE 	wbb".WBB_N."_post
			SET	isDeleted = 1,
				deleteTime = ".TIME_NOW.",
				deletedBy = '".escapeString(WCF::getUser()->username)."',
				deletedByID = ".WCF::getUser()->userID.",
				isDisabled = 0
			WHERE 	postID IN (".$postIDs.")";
		WCF::getDB()->sendQuery($sql);
	}
	
	/**
	 * Deletes all posts with the given post ids.
	 */
	public static function deleteAllCompletely($postIDs, $deleteAttachments = true, $deletePolls = true, $updateUserStats = true) {
		if (empty($postIDs)) return;
		
		// delete attachments
		if ($deleteAttachments) {
			require_once(WCF_DIR.'lib/data/attachment/MessageAttachmentListEditor.class.php');
			$attachment = new MessageAttachmentListEditor(explode(',', $postIDs));
			$attachment->deleteAll();
		}
		
		// delete polls
		if ($deletePolls) {
			require_once(WCF_DIR.'lib/data/message/poll/PollEditor.class.php');
			PollEditor::deleteAll($postIDs);
		}
		
		// update user posts & activity points
		if ($updateUserStats) {
			self::updateUserStats($postIDs, 'delete');
		}
		
		// delete sql data
		self::deleteData($postIDs);
	}
	
	/**
	 * Deletes the sql data of the posts with the given post ids.
	 */
	protected static function deleteData($postIDs) {
		// delete post, post_cache, post_hash and post_report
		$sql = "DELETE FROM 	wbb".WBB_N."_post
			WHERE 		postID IN (".$postIDs.")";
		WCF::getDB()->sendQuery($sql);
		
		$sql = "DELETE FROM	wbb".WBB_N."_post_cache
			WHERE 		postID IN (".$postIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		$sql = "DELETE FROM	wbb".WBB_N."_post_hash
			WHERE 		postID IN (".$postIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
		
		$sql = "DELETE FROM 	wbb".WBB_N."_post_report
			WHERE 		postID IN (".$postIDs.")";
		WCF::getDB()->registerShutdownUpdate($sql);
	}
	
	/**
	 * Resets first post id.
	 * 
	 * @param	string		$postIDs
	 */
	public static function resetFirstPostID($postIDs) {
		$sql = "UPDATE 	wbb".WBB_N."_thread
			SET	firstPostID = 0
			WHERE 	firstPostID IN (".$postIDs.")";
		WCF::getDB()->sendQuery($sql);
	}
	
	/**
	 * Returns the thread ids of the posts with the given post ids.
	 */
	public static function getThreadIDs($postIDs) {
		if (empty($postIDs)) return '';
		
		$threadIDs = '';
		$sql = "SELECT 	DISTINCT threadID
			FROM 	wbb".WBB_N."_post
			WHERE 	postID IN (".$postIDs.")";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (!empty($threadIDs)) $threadIDs .= ',';
			$threadIDs .= $row['threadID'];
		}
		
		return $threadIDs;
	}
	
	/**
	 * Updates the user stats (user posts, activity points & user rank).
	 * 
	 * @param	string		$postIDs		changed threads
	 * @param 	string		$mode			(enable|copy|move|delete)
	 * @param 	integer		$destinationBoardID
	 */
	public static function updateUserStats($postIDs, $mode, $destinationBoardID = 0) {
		if (empty($postIDs)) return;
		require_once(WBB_DIR.'lib/data/board/Board.class.php');
		
		// get destination board
		$destinationBoard = null;
		if ($destinationBoardID) $destinationBoard = Board::getBoard($destinationBoardID);
		if ($mode == 'copy' && !$destinationBoard->countUserPosts) return;
		
		// update user posts, activity points
		$userPosts = array();
		$userActivityPoints = array();
		$sql = "SELECT		post.userID, thread.boardID
			FROM		wbb".WBB_N."_post post
			LEFT JOIN	wbb".WBB_N."_thread thread
			ON		(thread.threadID = post.threadID)
			WHERE		post.postID IN (".$postIDs.")
					".($mode != 'enable' ? "AND post.everEnabled = 1" : '')."
					AND post.userID <> 0
					AND post.postID <> thread.firstPostID";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$board = Board::getBoard($row['boardID']);
			
			switch ($mode) {
				case 'enable':
					if ($board->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]++;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ACTIVITY_POINTS_PER_POST;
					}
					break;
				case 'copy':
					if ($destinationBoard->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]++;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ACTIVITY_POINTS_PER_POST;
					}
					break;
				case 'move':
					if ($board->countUserPosts != $destinationBoard->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']] += ($board->countUserPosts ? -1 : 1);
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] += ($board->countUserPosts ? ACTIVITY_POINTS_PER_POST * -1 : ACTIVITY_POINTS_PER_POST);
					}
					break;
				case 'delete':
					if ($board->countUserPosts) {
						// posts
						if (!isset($userPosts[$row['userID']])) $userPosts[$row['userID']] = 0;
						$userPosts[$row['userID']]--;
						// activity points
						if (!isset($userActivityPoints[$row['userID']])) $userActivityPoints[$row['userID']] = 0;
						$userActivityPoints[$row['userID']] -= ACTIVITY_POINTS_PER_POST;
					}
					break;
			}
		}
		
		// save posts
		if (count($userPosts)) {
			require_once(WBB_DIR.'lib/data/user/WBBUser.class.php');
			foreach ($userPosts as $userID => $posts) {
				WBBUser::updateUserPosts($userID, $posts);
			}
		}
		
		// save activity points
		if (count($userActivityPoints)) {
			require_once(WCF_DIR.'lib/data/user/rank/UserRank.class.php');
			foreach ($userActivityPoints as $userID => $points) {
				UserRank::updateActivityPoints($points, $userID);
			}
		}
	}
}
?>