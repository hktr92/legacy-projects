<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');
require_once(WBB_DIR.'lib/data/user/WBBUser.class.php');

// wcf imports
require_once(WCF_DIR.'lib/data/user/group/Group.class.php');

/**
 * Shows the list of boards on the start page.
 *
 * @package	com.woltlab.wbb.page
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class BoardList {
	protected $boardID = 0;
	protected $boardStructure;
	protected $boards;
	protected $boardList = array();
	protected $lastPosts = array();
	protected $subBoards = array();
	protected $newPosts = array();
	protected $unreadThreadsCount = array();
	protected $lastPostTimes = array();
	protected $inheritHiddenBoards = array();
	protected $visibleSQL = '';
	
	/**
	 * Creates a new BoardListPage object.
	 *	
	 * The boardID determines, which subboards are rendered.
	 * 0 means, that all boards are rendered.
	 *
	 * @param 	integer		$boardID		id of the parent board.
	 */
	public function __construct($boardID = 0) {
		$this->boardID = $boardID;
	}
	
	public function readParameters() {}
	
	/**
	 * Gets the post time of the last unread post for each board.
	 */
	protected function getLastPostTimes() {
		$sql = "SELECT 		boardID, thread.threadID, thread.lastPostTime
					".((WCF::getUser()->userID) ? (", thread_visit.lastVisitTime") : (", 0 AS lastVisitTime"))."
			FROM 		wbb".WBB_N."_thread thread
			".((WCF::getUser()->userID) ? ("
			LEFT JOIN 	wbb".WBB_N."_thread_visit thread_visit
			ON 		(thread_visit.threadID = thread.threadID AND thread_visit.userID = ".WCF::getUser()->userID.")
			") : (""))."
			WHERE 		thread.lastPostTime > ". WCF::getUser()->getLastVisitTime()."
					AND isDeleted = 0
					AND isDisabled = 0
					AND movedThreadID = 0"
					.(WCF::getSession()->getVisibleLanguages() ? " AND thread.languageID IN (".WCF::getSession()->getVisibleLanguages().")" : "");
		$result = WCF::getDB()->sendQuery($sql);
		
		while ($row = WCF::getDB()->fetchArray($result)) {
			if (WCF::getUser()->userID) $lastVisitTime = $row['lastVisitTime'];
			else $lastVisitTime = WCF::getUser()->getThreadVisitTime($row['threadID']);
			
			if ($row['lastPostTime'] > $lastVisitTime) {
				// count unread threads
				if ($row['lastPostTime'] > WCF::getUser()->getBoardVisitTime($row['boardID'])) {
					if (!isset($this->unreadThreadsCount[$row['boardID']])) $this->unreadThreadsCount[$row['boardID']] = 0;
					$this->unreadThreadsCount[$row['boardID']]++;
				}
				
				// save last post time
				if (!isset($this->lastPostTimes[$row['boardID']]) || $row['lastPostTime'] > $this->lastPostTimes[$row['boardID']]) {
					$this->lastPostTimes[$row['boardID']] = $row['lastPostTime'];
				}
			}
		}
	}

	/**
	 * Renders the list of boards on the index page or the list of subboards on a board page.
	 */
	public function renderBoards() {
		// get board structure from cache		
		$this->boardStructure = WCF::getCache()->get('board', 'boardStructure');
		
		if (!isset($this->boardStructure[$this->boardID])) {
			// the board with the given board id has no children
			WCF::getTPL()->assign('boards', array());
			return;
		}
		
		$this->readParameters();
		$this->getLastPostTimes();
		
		// get boards from cache
		$this->boards = WCF::getCache()->get('board', 'boards');
				
		// show newest posts on index
		if (BOARD_LIST_ENABLE_LAST_POST) {
			$lastPosts = WCF::getCache()->get('boardData', 'lastPosts');
			
			if (is_array($lastPosts)) {
				$visibleLanguages = false;
				if (WCF::getSession()->getVisibleLanguages()) {
					$visibleLanguages = explode(',', WCF::getSession()->getVisibleLanguages());
				}
				
				foreach ($lastPosts as $boardID => $languages) {
					foreach ($languages as $languageID => $row) {
						if (!$languageID || !$visibleLanguages || in_array($languageID, $visibleLanguages)) {
							$this->lastPosts[$row['boardID']] = new DatabaseObject($row);
							continue 2;
						}
					}
				}
			}
		}
		
		$this->clearBoardList($this->boardID);
		$this->makeBoardList($this->boardID, $this->boardID);
		WCF::getTPL()->assign('boards', $this->boardList);
		WCF::getTPL()->assign('newPosts', $this->newPosts);
		WCF::getTPL()->assign('unreadThreadsCount', $this->unreadThreadsCount);
		
		// show newest posts on index
		if (BOARD_LIST_ENABLE_LAST_POST) {
			WCF::getTPL()->assign('lastPosts', $this->lastPosts);
		}
	}
	
	/**
	 * Compares subboards for subboard sorting.
	 * 
	 * @param	Board		$boardA
	 * @param	Board		$boardB
	 * @return	integer
	 */
	protected static function compareSubBoards($boardA, $boardB) {
		return strcoll($boardA->title, $boardB->title);
	}
	
	/**
	 * Removes invisible boards from board list.
	 * 
	 * @param	integer		parentID		render the subboards of the board with the given id
	 */
	protected function clearBoardList($parentID = 0) {
		if (!isset($this->boardStructure[$parentID])) return;
		
		// remove invisible boards
		foreach ($this->boardStructure[$parentID] as $key => $boardID) {
			$board = $this->boards[$boardID];
			if (!$board->getPermission() || $board->isInvisible) {
				unset($this->boardStructure[$parentID][$key]);
				continue;
			}
			
			$this->clearBoardList($boardID);
		}
		
		if (!count($this->boardStructure[$parentID])) {
			unset($this->boardStructure[$parentID]);
		}
	}
	
	/**
	 * Renders one level of the board structure.
	 *
	 * @param	integer		parentID		render the subboards of the board with the given id
	 * @param	integer		subBoardFrom		helping variable for displaying the invisible subboards as a link under the parent board
	 * @param	integer		depth			the depth of the current level
	 * @param	integer		openParents		helping variable for rendering the html list in the boardlist template
	 * @param	integer		parentClosed		determines whether a parent category is collapsed
	 */
	protected function makeBoardList($parentID = 0, $subBoardsFrom = 0, $depth = 1, $openParents = 0, $parentClosed = 0) {
		if (!isset($this->boardStructure[$parentID])) return;
		
		$i = 0;
		$count = count($this->boardStructure[$parentID]);
		foreach ($this->boardStructure[$parentID] as $boardID) {
			$board = $this->boards[$boardID];
			if (!isset($this->lastPostTimes[$boardID])) {
				$this->lastPostTimes[$boardID] = 0;
			}
			
			// boardlist depth on index
			$updateNewPosts = 0;
			$updateBoardInfo = 1;
			$childrenOpenParents = $openParents + 1;
			$newSubBoardsFrom = $subBoardsFrom;
			if ($parentClosed == 0 && $depth <= BOARD_LIST_DEPTH && $subBoardsFrom == $parentID) {
				$updateBoardInfo = 0;
				$open = $depth + 1 <= BOARD_LIST_DEPTH;
				$hasChildren = isset($this->boardStructure[$boardID]) && $open;
				$last = ($i == ($count - 1));
				if ($hasChildren && !$last) $childrenOpenParents = 1;
				$this->boardList[] = array('open' => $open, 'depth' => $depth, 'hasChildren' => $hasChildren, 'openParents' => ((!$hasChildren && $last) ? ($openParents) : (0)), 'board' => $board);
				$newSubBoardsFrom = $boardID;
			}
			// board is invisible; show new posts in parent board
			else {
				$updateNewPosts = 1;
			}
			
			// make next level of the board list
			$this->makeBoardList($boardID, $newSubBoardsFrom, $depth + 1, $childrenOpenParents, $parentClosed);
			
			// user can not enter board; unset last post
			if (!$board->getPermission('canEnterBoard') && isset($this->lastPosts[$boardID])) {
				unset($this->lastPosts[$boardID]);
			}
			
			// show newest posts on index
			if ($updateBoardInfo && $parentID != 0 && BOARD_LIST_ENABLE_LAST_POST) {
				if (isset($this->lastPosts[$boardID])) {
					if (!isset($this->lastPosts[$parentID]) || $this->lastPosts[$boardID]->lastPostTime > $this->lastPosts[$parentID]->lastPostTime) {
						$this->lastPosts[$parentID] = $this->lastPosts[$boardID];
					}
				}
			}
			
			// board has unread posts
			if ($this->lastPostTimes[$boardID] > WCF::getUser()->getBoardVisitTime($boardID)) {
				$this->newPosts[$boardID] = true;
				if ($updateNewPosts) {
					// update unread thread count
					if (isset($this->unreadThreadsCount[$boardID])) {
						if (!isset($this->unreadThreadsCount[$parentID])) $this->unreadThreadsCount[$parentID] = 0;
						$this->unreadThreadsCount[$parentID] += $this->unreadThreadsCount[$boardID];
					}
				
					// update last post time
					if (!isset($this->lastPostTimes[$parentID]) || $this->lastPostTimes[$parentID] < $this->lastPostTimes[$boardID]) {
						$this->lastPostTimes[$parentID] = $this->lastPostTimes[$boardID];
					}
				}
			}
			else {
				$this->newPosts[$boardID] = false;
			}
			
			$i++;
		}
	}
}
?>