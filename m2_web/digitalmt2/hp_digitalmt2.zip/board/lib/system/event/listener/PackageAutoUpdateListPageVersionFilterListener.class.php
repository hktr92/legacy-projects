<?php
// wcf imports
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');
require_once(WCF_DIR.'lib/acp/package/update/PackageUpdate.class.php');
require_once(WCF_DIR.'lib/acp/package/Package.class.php');

/**
 * Filters the auto update package list.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2008 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.system.event.listener
 */
class PackageAutoUpdateListPageVersionFilterListener implements EventListener {
	/**
	 * @see EventListener::execute()
	 */
	public function execute($eventObj, $className, $eventName) {
		foreach ($eventObj->availableUpdates as $packageID => $update) {
			if ($update['package'] == 'com.woltlab.wbb') {
				$currentVersion = $update['packageVersion'];
				if (Package::compareVersion($currentVersion, '3.0.0 Beta 1', '<')) {
					foreach ($update['versions'] as $version => $versionData) {
						if (Package::compareVersion($version, '3.0.0 Beta 1', '>=')) {
							unset($update['versions'][$version]);
						}
					}
					
					if (!count($update['versions'])) {
						$eventObj->availableUpdates = PackageUpdate::getAvailableUpdates(false);
						unset($eventObj->availableUpdates[$packageID]);
					}
					else {
						$eventObj->availableUpdates[$packageID]['versions'] = $update['versions'];
						$eventObj->availableUpdates[$packageID]['version'] = end($update['versions']);
					}
				}
			}
		}
	}
}
?>