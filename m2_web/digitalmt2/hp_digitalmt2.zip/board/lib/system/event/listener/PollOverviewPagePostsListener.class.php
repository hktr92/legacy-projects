<?php
// wcf imports
require_once(WCF_DIR.'lib/system/event/EventListener.class.php');

/**
 * Checks the permissions for viewing the poll overview page.
 * 
 * @author 	Marcel Werk
 * @copyright	2001-2009 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	system.event.listener
 * @category 	Burning Board
 */
class PollOverviewPagePostsListener implements EventListener {
	/**
	 * @see EventListener::execute()
	 */
	public function execute($eventObj, $className, $eventName) {
		if ($eventObj->poll->messageType == 'post') {
			// check permissions
			require_once(WBB_DIR.'lib/data/post/Post.class.php');
			$post = new Post($eventObj->poll->messageID);
			if (!$post->postID) {
				throw new IllegalLinkException();
			}
			require_once(WBB_DIR.'lib/data/thread/Thread.class.php');
			$thread = new Thread($post->threadID);
			$thread->enter();
			require_once(WBB_DIR.'lib/data/board/Board.class.php');
			$board = new Board($thread->boardID);
			$eventObj->canVotePoll = $board->getPermission('canVotePoll');
			
			// plug in breadcrumbs
			WCF::getTPL()->assign(array(
				'board' => $board,
				'thread' => $thread,
				'showThread' => true
			));
			WCF::getTPL()->append('specialBreadCrumbs', WCF::getTPL()->fetch('navigation'));
		}
	}
}
?>