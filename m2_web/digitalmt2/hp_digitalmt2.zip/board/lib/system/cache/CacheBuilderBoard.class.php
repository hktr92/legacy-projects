<?php
// wbb imports
require_once(WBB_DIR.'lib/data/board/Board.class.php');

// wcf imports
require_once(WCF_DIR.'lib/system/cache/CacheBuilder.class.php');
require_once(WCF_DIR.'lib/data/user/group/Group.class.php');
require_once(WCF_DIR.'lib/data/user/User.class.php');

/**
 * Caches all boards, the structure of boards and all moderators.
 * 
 * @package	com.woltlab.wbb.system.cache
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 */
class CacheBuilderBoard implements CacheBuilder {
	/**
	 * @see CacheBuilder::getData()
	 */
	public function getData($cacheResource) {
		$data = array('boards' => array(), 'boardStructure' => array(), 'moderators' => array());
		
		// boards
		$sql = "SELECT	*
			FROM 	wbb".WBB_N."_board";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$data['boards'][$row['boardID']] = new Board(null, $row);
		}
		
		// board structure
		$sql = "SELECT		*
			FROM 		wbb".WBB_N."_board_structure
			ORDER BY 	parentID ASC, position ASC";
		$result = WCF::getDB()->sendQuery($sql);
		while ($row = WCF::getDB()->fetchArray($result)) {
			$data['boardStructure'][$row['parentID']][] = $row['boardID'];
		}
		
		return $data;
	}
}
?>