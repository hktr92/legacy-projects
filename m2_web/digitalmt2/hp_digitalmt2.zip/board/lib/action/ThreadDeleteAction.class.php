<?php
require_once(WBB_DIR.'lib/action/ThreadCloseAction.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadAction.class.php');
require_once(WBB_DIR.'lib/data/board/BoardEditor.class.php');

/**
 * Deletes a thread.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.action
 */
class ThreadDeleteAction extends ThreadCloseAction {
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		AbstractAction::execute();
		
		// check permission
		WCF::getUser()->checkPermission('mod.board.canDeleteThreadCompletely');
				
		// delete thread
		$threadAction = new ThreadAction(new BoardEditor($this->thread->boardID), $this->thread);
		$threadAction->delete();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=Board&boardID='.$this->thread->boardID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>