<?php
require_once(WBB_DIR.'lib/action/ThreadCloseAction.class.php');

/**
 * Opens a thread.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.action
 */
class ThreadOpenAction extends ThreadCloseAction {
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		AbstractAction::execute();
		
		// check permission
		WCF::getUser()->checkPermission('mod.board.canCloseThread');
				
		// close thread
		$this->thread->open();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=Thread&threadID='.$this->threadID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>