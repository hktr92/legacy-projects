<?php
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');

/**
 * Moves a thread.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.action
 */
class ThreadMoveAction extends AbstractAction {
	public $threadID = 0;
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['threadID'])) $this->threadID = intval($_REQUEST['threadID']);
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		AbstractAction::execute();
		
		// forward to form
		HeaderUtil::redirect('index.php?form=ThreadMove&threadID='.$this->threadID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>