<?php
require_once(WCF_DIR.'lib/action/AbstractSecureAction.class.php');

/**
 * Marks all boards as read.
 * 
 * @author 	Marcel Werk
 * @copyright	2001-2009 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb
 * @subpackage	action
 * @category 	Burning Board
 */
class BoardMarkAllAsReadAction extends AbstractSecureAction {
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// set last mark as read time
		WCF::getUser()->setLastMarkAllAsReadTime(TIME_NOW);
		
		// reset session
		WCF::getSession()->resetUserData();
		$this->executed();
		
		if (empty($_REQUEST['ajax'])) HeaderUtil::redirect('index.php'.SID_ARG_1ST);
		exit;
	}
}
?>