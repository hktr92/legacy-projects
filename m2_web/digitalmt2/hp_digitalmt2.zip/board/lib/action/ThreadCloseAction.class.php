<?php
require_once(WCF_DIR.'lib/action/AbstractAction.class.php');
require_once(WBB_DIR.'lib/data/thread/ThreadEditor.class.php');

/**
 * Closes a thread.
 * 
 * @author	Marcel Werk
 * @copyright	2001-2007 WoltLab GmbH
 * @license	WoltLab Burning Board License <http://www.woltlab.com/products/burning_board/license.php>
 * @package	com.woltlab.wbb.action
 */
class ThreadCloseAction extends AbstractAction {
	public $threadID = 0;
	public $thread;
	
	/**
	 * @see Action::readParameters()
	 */
	public function readParameters() {
		parent::readParameters();
		
		if (isset($_REQUEST['threadID'])) $this->threadID = intval($_REQUEST['threadID']);
		$this->thread = new ThreadEditor($this->threadID);
		if (!$this->thread->threadID) {
			require_once(WCF_DIR.'lib/system/exception/IllegalLinkException.class.php');
			throw new IllegalLinkException();
		}
	}
	
	/**
	 * @see Action::execute()
	 */
	public function execute() {
		parent::execute();
		
		// check permission
		WCF::getUser()->checkPermission('mod.board.canCloseThread');
				
		// close thread
		$this->thread->close();
		
		// forward to list page
		HeaderUtil::redirect('index.php?page=Thread&threadID='.$this->threadID.SID_ARG_2ND_NOT_ENCODED);
		exit;
	}
}
?>